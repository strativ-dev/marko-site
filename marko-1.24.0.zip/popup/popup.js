"use strict";

const APP_URL = "https://strativ-dev.github.io/marko-site/app.html";
const SIGNIN_URL = "https://strativ-dev.github.io/marko-site/signin.html";
const MENTIONS_URL = APP_URL + "#/mentions";

const $ = (s) => document.querySelector(s);

const api = (path, opts) => MarkoDB.api(path, opts);

function show(id) {
  ["view-loading", "view-welcome", "view-project", "view-noproject"].forEach((v) => {
    const el = document.getElementById(v);
    if (el) el.hidden = v !== id;
  });
}

// Mac shows ⌘⇧M; everyone else Alt+M. Keep in sync with the content-script
// toggle in content.js.
const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
const TOGGLE_HINT = IS_MAC ? "⌘⇧M" : "Alt+M";

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function startReview(tab, project) {
  // Hand the project to the content script and open the review dock.
  // Explicitly starting review turns Marko on if it was toggled off.
  await MarkoDB.setSettings({ activeProject: { id: project.id, name: project.name, url: project.url }, markoOff: false });
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "MARKO_START_ANNOTATION", project });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [
        "js/marko-db.js",
        "js/marko-review.js",
        "js/content.js",
      ],
    });
    await chrome.tabs.sendMessage(tab.id, { type: "MARKO_START_ANNOTATION", project });
  }
  window.close();
}

async function renderMentions() {
  const row = $("#btn-mentions");
  row.hidden = false;
  row.onclick = async () => {
    await chrome.tabs.create({ url: MENTIONS_URL });
    window.close();
  };
  try {
    const data = await api("/notifications");
    const unread = Number(data.unread) || 0;
    const total = Number(data.total) || 0;
    $("#mentions-count").textContent = unread ? String(unread) : "";
    $("#mentions-label").textContent = unread
      ? unread + (unread === 1 ? " new mention" : " new mentions")
      : total ? "Mentions" : "No mentions yet";
    row.classList.toggle("none", !unread);
  } catch {
    $("#mentions-label").textContent = "Mentions";
    row.classList.add("none");
  }
}

// Master on/off. When off, Marko never mounts on any page — browse freely.
async function setMarkoEnabled(enabled) {
  await MarkoDB.setSettings({ markoOff: !enabled });
  reflectToggle(enabled);
  // Tell every open tab to start or stop immediately.
  try {
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (t.id) chrome.tabs.sendMessage(t.id, { type: "MARKO_SET_ENABLED", enabled }).catch(() => {});
    }
  } catch {}
}
function reflectToggle(enabled) {
  const row = $("#marko-toggle-row"), sw = $("#marko-switch");
  if (!row || !sw) return;
  sw.checked = enabled;
  row.classList.toggle("off", !enabled);
  $("#mt-sub").textContent = enabled
    ? "Active — click a page element to pin"
    : "Off — Marko won't appear on any page";
}

async function route() {
  const settings = await MarkoDB.getSettings();
  if (!MarkoDB.isValid(settings)) {
    show("view-welcome");
    $("#btn-mentions").hidden = true;
    $("#marko-toggle-row").hidden = true;
    return;
  }
  // Signed in: show a loader immediately so the popup is never blank while the
  // project lookup (a network round-trip) is in flight.
  show("view-loading");
  $("#marko-toggle-row").hidden = false;
  reflectToggle(!settings.markoOff);
  renderMentions();

  const tab = await activeTab();
  const pageUrl = tab?.url || "";
  const isHttp = /^https?:\/\//.test(pageUrl);
  let host = "";
  try { host = new URL(pageUrl).host; } catch {}

  if (!isHttp) {
    show("view-noproject");
    $("#current-host").textContent = "This page can't be reviewed";
    $("#btn-create-project").disabled = true;
    return;
  }

  try {
    // counts=1: the popup is the only caller that shows active/resolved totals.
    const data = await api("/projects/find?url=" + encodeURIComponent(pageUrl) + "&counts=1");
    if (data.project) {
      $("#proj-name").textContent = data.project.name;
      $("#proj-host").textContent = host;
      $("#proj-active").textContent = (data.counts?.active ?? 0) + " active";
      $("#proj-resolved").textContent = (data.counts?.resolved ?? 0) + " resolved";
      show("view-project");
      const kbd = document.querySelector("#btn-review .kbd");
      if (kbd) kbd.textContent = TOGGLE_HINT;
      // The content script refuses to mount on Marko's own app pages, so the
      // button would silently do nothing there. Say why instead.
      if (MarkoDB.isOwnSurface(pageUrl)) {
        const btn = $("#btn-review");
        btn.disabled = true;
        btn.querySelector(".k").textContent = "Can't review Marko itself";
        if (kbd) kbd.hidden = true;
      } else {
        $("#btn-review").onclick = () => startReview(tab, data.project);
      }
      $("#btn-open-app").onclick = async () => {
        await chrome.tabs.create({ url: APP_URL + "#/p/" + data.project.id });
        window.close();
      };
      return;
    }
  } catch {
    // network error: fall through to the create view, button will surface errors
  }

  show("view-noproject");
  $("#current-host").textContent = host;
  $("#btn-create-project").disabled = false;
  $("#btn-create-project").onclick = async () => {
    const btn = $("#btn-create-project");
    const st = $("#create-status");
    btn.disabled = true;
    st.innerHTML = '<span class="spinner"></span> Creating project…';
    st.className = "status";
    try {
      const { project } = await api("/projects", {
        method: "POST",
        body: JSON.stringify({ name: host, url: pageUrl }),
      });
      st.textContent = "Project created.";
      st.className = "status ok";
      await startReview(tab, project);
    } catch (e) {
      if (e.message === "project_exists" && e.data?.project) {
        st.textContent = "Project already exists. Opening it…";
        st.className = "status ok";
        await startReview(tab, e.data.project);
        return;
      }
      st.textContent = "Failed: " + (e.message || e);
      st.className = "status err";
      btn.disabled = false;
    }
  };
}

$("#btn-get-started").addEventListener("click", async () => {
  await chrome.tabs.create({ url: SIGNIN_URL });
  window.close();
});
$("#btn-open-app-2").addEventListener("click", async () => {
  await chrome.tabs.create({ url: APP_URL });
  window.close();
});
$("#marko-switch").addEventListener("change", (e) => setMarkoEnabled(e.target.checked));

route();
