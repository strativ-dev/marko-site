"use strict";

document.getElementById("btn-try").addEventListener("click", async () => {
  // Open example.com in a new tab so user can try annotating immediately
  await chrome.tabs.create({ url: "https://example.com" });
});

document.getElementById("btn-settings").addEventListener("click", async (e) => {
  e.preventDefault();
  await chrome.tabs.create({
    url: chrome.runtime.getURL("settings/settings.html"),
  });
});
