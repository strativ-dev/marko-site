"use strict";

// Receives a Supabase session bridged from the web sign-in (in the URL hash)
// and stores it in chrome.storage so the extension is signed in too.

const SETTINGS_KEY = "marko:settings";

function fail(msg) {
  const t = document.getElementById("title");
  const d = document.getElementById("detail");
  if (t) { t.textContent = "Sign-in failed"; t.classList.add("err"); }
  if (d) d.textContent = msg;
}

async function closeSelf() {
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab?.id) await chrome.tabs.remove(tab.id);
  } catch {
    try { window.close(); } catch {}
  }
}

// Pull the user id (sub) out of a Supabase JWT without verifying it — the
// token is trusted here only to label the local session; every real request
// is re-checked server-side by Supabase.
function subOf(jwt) {
  try {
    const b = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    const pad = b.length % 4 ? "=".repeat(4 - (b.length % 4)) : "";
    return JSON.parse(atob(b + pad)).sub || "";
  } catch { return ""; }
}

(async () => {
  const raw = (location.hash || "").replace(/^#/, "");
  if (!raw) return fail("No session data in the callback URL.");
  const params = new URLSearchParams(raw);
  const access = params.get("at");
  const refresh = params.get("rt");
  const exp = Number(params.get("exp")) || 0;
  const email = params.get("email");
  const name = params.get("name") || (email || "").split("@")[0] || "";
  const avatar = params.get("avatar") || "";

  if (!access || !refresh || !email) return fail("Missing session data.");
  if (exp && exp < Date.now() + 30_000) return fail("Session already expired.");

  try {
    const res = await chrome.storage.local.get(SETTINGS_KEY);
    const settings = res[SETTINGS_KEY] || {};
    settings.sbAccess = access;
    settings.sbRefresh = refresh;
    settings.sbExp = exp;
    settings.user = { id: subOf(access), email, name, avatar };
    // Retire any leftover Cloudflare-Worker session fields.
    delete settings.emailSession;
    delete settings.emailSessionExp;
    await chrome.storage.local.set({ [SETTINGS_KEY]: settings });

    document.getElementById("title").textContent = "You're signed in";
    if (window.top !== window) {
      document.getElementById("detail").textContent = "You can close this.";
      try { window.parent.postMessage({ type: "marko-auth-ok" }, "*"); } catch {}
      return;
    }
    document.getElementById("detail").textContent = "Closing this tab…";
    setTimeout(closeSelf, 700);
  } catch (e) {
    fail((e && e.message) || String(e));
  }
})();
