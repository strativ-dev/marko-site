"use strict";

(() => {
  if (window.__MARKO_LOADED__) return;
  window.__MARKO_LOADED__ = true;

  const R = window.__MARKO_REVIEW__;
  if (!R) return;

  async function isSignedIn() {
    try { return MarkoDB.isValid(await MarkoDB.getSettings()); }
    catch { return false; }
  }
  // Master switch (popup toggle). When off, Marko never mounts — browse freely.
  async function isMarkoOff() {
    try { return !!(await MarkoDB.getSettings()).markoOff; }
    catch { return false; }
  }
  function showSignInGate() {
    const existing = document.getElementById("marko-signin-gate");
    if (existing) { existing.style.opacity = "1"; return; }
    const el = document.createElement("div");
    el.id = "marko-signin-gate";
    el.style.cssText =
      "all: initial; position: fixed; top: 16px; left: 50%; transform: translateX(-50%);" +
      "background:#0b0b0f; color:#fff; padding:12px 18px; border-radius:999px;" +
      "font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, sans-serif;" +
      "box-shadow: 0 10px 30px rgba(0,0,0,.35); z-index: 2147483647; cursor:pointer;";
    el.textContent = "Sign in from the Marko popup to start reviewing";
    el.addEventListener("click", () => el.remove());
    document.documentElement.appendChild(el);
    setTimeout(() => el.remove(), 6000);
  }

  // Shared with the popup (MarkoDB.isOwnSurface) so the button's enabled state
  // and the dock's mount decision can never disagree.
  const isOwnSurface = () => MarkoDB.isOwnSurface(location.href);

  async function guardedStart(project) {
    if (isOwnSurface()) return;
    if (await isMarkoOff()) return;
    if (!(await isSignedIn())) { showSignInGate(); return; }
    R.start(project);
  }

  // On-canvas widget: when the site already has a project,
  // mount the dock automatically in browse mode (pins visible, comment
  // toggle off) without needing the popup.
  async function autoMount() {
    try {
      if (R.active) return;
      if (isOwnSurface()) return;
      if (!/^https?:$/.test(location.protocol)) return;
      if (await isMarkoOff()) return;
      if (!(await isSignedIn())) return;
      const data = await MarkoDB.api("/projects/find?url=" + encodeURIComponent(location.href));
      if (data.project) R.start(data.project, { comment: false });
    } catch { /* stay quiet on pages we can't reach the backend from */ }
  }
  autoMount();

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== "object") return;
    switch (msg.type) {
      case "MARKO_START_ANNOTATION":
        guardedStart(msg.project).then(() => sendResponse({ ok: true }));
        return true;
      case "MARKO_STOP_ANNOTATION":
        R.stop();
        sendResponse({ ok: true });
        break;
      case "MARKO_PING":
        sendResponse({ ok: true, active: R.active });
        break;
      case "MARKO_SET_ENABLED":
        // Popup master toggle. Off → tear the dock down now; On → try to mount.
        if (msg.enabled) { autoMount(); } else { R.stop(); }
        sendResponse({ ok: true });
        break;
    }
    return true;
  });

  document.addEventListener("keydown", (e) => {
    // Toggle: Alt+M (Win/Linux) or Cmd+Shift+M / Ctrl+Shift+M (Mac-friendly,
    // avoids Option+M inserting "µ"). e.code sidesteps the altered character.
    const isM = e.code === "KeyM";
    // Cmd+Ctrl+M (Mac) / Ctrl+Alt+M flips the comment-mode switch — the pill
    // that stays on screen in browse mode. Checked before the start/stop combo
    // below, which requires Shift and so can't collide. Nothing to toggle
    // until the dock is mounted, so mount first when it isn't.
    const commentCombo = e.metaKey ? e.ctrlKey && !e.shiftKey : e.ctrlKey && e.altKey && !e.shiftKey;
    if (isM && commentCombo) {
      e.preventDefault();
      if (R.active) R.setCommentMode(!R.commentMode);
      else isMarkoOff().then((off) => { if (!off) guardedStart(); });
      return;
    }
    const combo =
      (e.altKey && !e.metaKey && !e.ctrlKey) ||
      ((e.metaKey || e.ctrlKey) && e.shiftKey);
    if (isM && combo) {
      e.preventDefault();
      if (R.active) R.stop();
      else isMarkoOff().then((off) => { if (!off) guardedStart(); });
      return;
    }
    if (e.key === "Escape" && R.active) {
      const tag = (document.activeElement && document.activeElement.tagName) || "";
      if (tag === "TEXTAREA" || tag === "INPUT") return;
      R.stop();
    }
  });
})();
