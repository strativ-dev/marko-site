"use strict";

/**
 * Marko share encoder — compress a report to a URL-safe fragment string.
 * Uses gzip (CompressionStream) + base64url so browsers accept it in URLs.
 */

(() => {
  if (window.__MARKO_SHARE__) return;

  function b64urlEncode(bytes) {
    let str = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      str += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function b64urlDecode(str) {
    const s = str.replace(/-/g, "+").replace(/_/g, "/");
    const pad = s.length % 4 ? "=".repeat(4 - (s.length % 4)) : "";
    const bin = atob(s + pad);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  async function compress(json) {
    const input = new TextEncoder().encode(json);
    if (typeof CompressionStream !== "function") return input;
    const cs = new CompressionStream("gzip");
    const stream = new Blob([input]).stream().pipeThrough(cs);
    const buf = await new Response(stream).arrayBuffer();
    return new Uint8Array(buf);
  }

  async function decompress(bytes) {
    if (typeof DecompressionStream !== "function") {
      return new TextDecoder().decode(bytes);
    }
    const ds = new DecompressionStream("gzip");
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    const buf = await new Response(stream).arrayBuffer();
    return new TextDecoder().decode(buf);
  }

  async function encodeReport(report) {
    const json = JSON.stringify(report);
    const bytes = await compress(json);
    return b64urlEncode(bytes);
  }

  async function decodeReport(str) {
    const bytes = b64urlDecode(str);
    const json = await decompress(bytes);
    return JSON.parse(json);
  }

  window.__MARKO_SHARE__ = { encodeReport, decodeReport, b64urlEncode, b64urlDecode };
})();
