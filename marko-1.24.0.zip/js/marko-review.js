"use strict";

/**
 * Marko review mode: in-page project review.
 *
 * Bottom-left dock (panel toggle, share, copy link), comment/browse
 * toggle, top-right resolution pill, element-anchored pins that POST
 * comments to the worker, side panel with Active/Resolved tabs, share
 * popover, @mention autocomplete.
 *
 * Exposed as window.__MARKO_REVIEW__ = { start(project), stop(), active }.
 */
(() => {
  if (window.__MARKO_REVIEW__) return;

  const APP_URL = "https://strativ-dev.github.io/marko-site/app.html";
  // Shortcut for the comment-mode switch. Keep in sync with the key handler in
  // content.js, which is what actually listens.
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
  const COMMENT_HINT = IS_MAC ? "⌘⌃M" : "Ctrl+Alt+M";
  const SEVERITIES = [
    { id: "neutral", label: "Neutral", color: "#0099ff" },
    { id: "low", label: "Low", color: "#22c55e" },
    { id: "medium", label: "Medium", color: "#eab308" },
    { id: "high", label: "High", color: "#f97316" },
    { id: "critical", label: "Critical", color: "#e5484d" },
  ];
  const RESOLUTIONS = [
    { group: "Desktop", icon: "desktop", items: [
      ["4K", 3840, 2160], ["Full HD", 1920, 1080], ["Surface Book", 1500, 1000],
      ["Macbook Air", 1280, 832], ['Macbook Pro 14"', 1512, 982], ['Macbook Pro 16"', 1728, 1117],
      ["Laptop S", 1024, 768], ["Laptop M", 1366, 768],
    ]},
    { group: "Tablet", icon: "tablet", items: [
      ['iPad Pro 12.9"', 1024, 1366], ['iPad Pro 11"', 834, 1194], ["iPad mini", 768, 1024],
    ]},
    { group: "Phone", icon: "phone", items: [
      ["iPhone 14 & 15 Pro Max", 430, 932], ["iPhone 14 & 15 Pro", 393, 852],
      ["iPhone 13 & 14", 390, 844], ["iPhone 14 Plus", 428, 926],
      ["iPhone 13 mini", 375, 812], ["iPhone SE", 320, 568],
      ["iPhone 8 Plus", 414, 736], ["iPhone 8", 375, 667],
      ["Google Pixel 2 XL", 411, 823], ["Google Pixel 2", 411, 731],
      ["Android", 360, 640],
    ]},
  ];
  const GROUP_ICONS = {
    desktop: '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
    tablet: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M11 18h2"/>',
    phone: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  };


  const S = {
    active: false,
    commentMode: true,
    project: null,
    pins: [],
    settings: null,
    root: null,       // shadow host
    shadow: null,
    tab: "active",    // panel tab
    panelOpen: false,
    composer: null,   // { x, y, el, selector, xr, yr }
    members: [],
  };

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const initials = (s) => (String(s || "?").trim()[0] || "?").toUpperCase();
  const sevOf = (h) => SEVERITIES.find((s) => s.id === h.severity) || SEVERITIES[0];
  const AV_COLORS = ["#0099ff","#7c5cff","#f97316","#e5484d","#16a34a","#eab308","#06b6d4","#ec4899","#8b5cf6","#f43f5e","#14b8a6","#f59e0b"];
  const avatarColor = (seed) => { const s = String(seed || "?"); let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return AV_COLORS[h % AV_COLORS.length]; };
  const MENTION_RE = /@([a-zA-Z0-9._%+-]+)@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const localPart = (e) => String(e || "").split("@")[0];
  // Saved comments: the domain is noise once the mention is resolved, so show
  // just the local part and keep the full address on hover. The stored text is
  // untouched — the notification triggers scrape full emails out of it.
  const renderText = (t) => esc(t).replace(MENTION_RE, (m, user) => `<span class="mkmention" title="${m}">@${user}</span>`);

  const getSettings = () => MarkoDB.getSettings();
  const api = (path, opts) => MarkoDB.api(path, opts);

  /* ── selector helpers ── */
  function cssPath(el) {
    if (!(el instanceof Element)) return "";
    const parts = [];
    while (el && el.nodeType === 1 && parts.length < 8) {
      let sel = el.nodeName.toLowerCase();
      if (el.id) { parts.unshift(sel + "#" + CSS.escape(el.id)); break; }
      const parent = el.parentElement;
      if (parent) {
        const sibs = [...parent.children].filter((c) => c.nodeName === el.nodeName);
        if (sibs.length > 1) sel += `:nth-of-type(${sibs.indexOf(el) + 1})`;
      }
      parts.unshift(sel);
      el = parent;
    }
    return parts.join(" > ");
  }
  function resolvePin(h) {
    let el = null;
    try { el = document.querySelector(h.selector); } catch {}
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) return null;
    return {
      x: r.left + window.scrollX + r.width * (h.xr || 0),
      y: r.top + window.scrollY + r.height * (h.yr || 0),
      el,
    };
  }

  /* ── UI scaffold ── */
  function mount() {
    S.root = document.createElement("div");
    S.root.id = "marko-review-root";
    S.root.style.cssText = "all: initial; position: absolute; top: 0; left: 0; z-index: 2147483646;";
    S.shadow = S.root.attachShadow({ mode: "open" });
    S.shadow.innerHTML = `<style>${CSS_TEXT}</style>
      <div id="pins"></div>
      <div id="hover-box" hidden></div>
      <div id="dock">
        <button id="d-panel" class="fab big" title="Comments panel">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        </button>
        <button id="d-share" class="fab" title="Share project">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5 6 6-6 6"/><path d="M21 11H9a6 6 0 0 0-6 6v2"/></svg>
        </button>
        <button id="d-link" class="fab" title="Copy project link">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
        </button>
        <span id="d-avatar" class="avatar" title=""></span>
      </div>
      <div id="mode-toggle" title="Toggle comment mode (${COMMENT_HINT})">
        <span class="track"><span class="knob">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        </span></span>
      </div>
      <div id="res-pill">
        <button id="res-btn">${window.innerWidth} x ${window.innerHeight}
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div id="res-menu" hidden></div>
      </div>
      <div id="panel" hidden></div>
      <div id="popover-host"></div>`;
    document.documentElement.appendChild(S.root);

    S.shadow.getElementById("d-panel").addEventListener("click", togglePanel);
    S.shadow.getElementById("d-share").addEventListener("click", openShare);
    S.shadow.getElementById("d-link").addEventListener("click", copyLink);
    S.shadow.getElementById("mode-toggle").addEventListener("click", () => setCommentMode(!S.commentMode));
    S.shadow.getElementById("res-btn").addEventListener("click", toggleResMenu);
    const av = S.shadow.getElementById("d-avatar");
    const avatarUrl = S.settings.user?.avatar || "";
    if (avatarUrl) {
      av.textContent = "";
      av.style.background = "transparent";
      const img = document.createElement("img");
      img.src = avatarUrl;
      img.alt = "";
      img.referrerPolicy = "no-referrer";
      av.appendChild(img);
    } else {
      av.textContent = initials(S.settings.user?.name || S.settings.user?.email);
      av.style.background = avatarColor(S.settings.user?.email || S.settings.user?.name);
    }
    av.title = S.settings.user?.email || "";
    renderResMenu();
    setCommentMode(S.commentMode);
  }

  // Named so unmount can actually remove it. An inline arrow would leave one
  // live listener behind per start/stop cycle, forever.
  function onWindowResize() { schedulePins(); updateResLabel(); }

  function unmount() {
    if (S.root) S.root.remove();
    S.root = S.shadow = null;
    document.removeEventListener("click", onPageClick, true);
    document.removeEventListener("mousemove", onPageMove, true);
    window.removeEventListener("scroll", schedulePins, true);
    window.removeEventListener("resize", onWindowResize);
  }

  /* ── comment mode ── */
  function setCommentMode(on) {
    S.commentMode = on;
    const t = S.shadow.getElementById("mode-toggle");
    t.classList.toggle("on", on);
    document.documentElement.style.cursor = on ? "crosshair" : "";

    // Browse mode gets the page back: everything except the toggle itself
    // goes away, so nothing of Marko's overlaps what you're looking at.
    S.shadow.getElementById("dock").hidden = !on;
    S.shadow.getElementById("res-pill").hidden = !on;
    S.shadow.getElementById("pins").hidden = !on;
    // Pins are not repositioned while hidden, so refresh them on the way back.
    if (on) renderPins();
    if (!on) {
      hideHover();
      closePopovers();
      if (S.panelOpen) {
        S.panelOpen = false;
        S.shadow.getElementById("panel").hidden = true;
        setPanelFabIcon();
      }
    }
  }

  /* hover highlight: outline the element under the cursor in comment mode */
  function hideHover() {
    const box = S.shadow && S.shadow.getElementById("hover-box");
    if (box) box.hidden = true;
  }
  function onPageMove(e) {
    if (!S.active || !S.commentMode || !S.shadow) return;
    if (e.composedPath().includes(S.root)) { hideHover(); return; }
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === document.documentElement || el === document.body) { hideHover(); return; }
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) { hideHover(); return; }
    const box = S.shadow.getElementById("hover-box");
    box.style.left = (r.left + window.scrollX) + "px";
    box.style.top = (r.top + window.scrollY) + "px";
    box.style.width = r.width + "px";
    box.style.height = r.height + "px";
    box.hidden = false;
  }

  function onPageClick(e) {
    if (!S.active || !S.commentMode) return;
    // A just-clicked mention suggestion hides itself, so the trailing click can
    // land on the page behind it — don't let that drop a stray pin.
    if (Date.now() < (S.suppressClickUntil || 0)) return;
    const path = e.composedPath();
    if (path.includes(S.root)) return; // clicks on our own UI
    e.preventDefault();
    e.stopPropagation();
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el) return;
    const r = el.getBoundingClientRect();
    openComposer({
      x: e.clientX + window.scrollX,
      y: e.clientY + window.scrollY,
      selector: cssPath(el),
      xr: r.width ? (e.clientX - r.left) / r.width : 0,
      yr: r.height ? (e.clientY - r.top) / r.height : 0,
    });
  }

  /* ── element screenshot ── */
  // Grab the visible tab and crop to the pinned element plus some breathing
  // room, so a reviewer sees what was being pointed at without leaving the
  // comment. Returns "" on any failure -- a pin is still worth saving.
  // Padding around the pinned element in the screenshot, so a reviewer sees
  // surrounding context (siblings, layout) not just the bare element. Scales
  // with the element and is clamped so tiny elements still get real context
  // and huge ones don't blow up the crop.
  const SHOT_MAX_W = 1200;
  const shotPad = (dim) => Math.min(320, Math.max(64, Math.round(dim * 0.6)));
  async function captureRegion(selector) {
    // A screenshot is a nice-to-have; never let it hold up the comment.
    return Promise.race([
      captureRegionInner(selector),
      new Promise((res) => setTimeout(() => res(""), 4000)),
    ]).catch(() => "");
  }
  async function captureRegionInner(selector) {
    try {
      let el = null;
      try { el = document.querySelector(selector); } catch {}
      if (!el) return "";
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return "";

      // Hide our own overlay so it doesn't end up in the capture.
      S.root.style.visibility = "hidden";
      // setTimeout, not rAF: a backgrounded tab never fires rAF and the
      // capture would hang, taking the comment save down with it.
      await new Promise((res) => setTimeout(res, 60));
      const reply = await chrome.runtime.sendMessage({ type: "MARKO_CAPTURE_VISIBLE" });
      S.root.style.visibility = "";
      if (!reply || !reply.ok || !reply.dataUrl) return "";

      const img = await new Promise((res, rej) => {
        const i = new Image();
        i.onload = () => res(i);
        i.onerror = rej;
        i.src = reply.dataUrl;
      });

      // captureVisibleTab returns device pixels; rects are CSS pixels.
      const scale = img.width / window.innerWidth;
      const padX = shotPad(r.width);
      const padY = shotPad(r.height);
      const sx = Math.max(0, (r.left - padX) * scale);
      const sy = Math.max(0, (r.top - padY) * scale);
      const sw = Math.min(img.width - sx, (r.width + padX * 2) * scale);
      const sh = Math.min(img.height - sy, (r.height + padY * 2) * scale);
      if (sw < 2 || sh < 2) return "";

      const outW = Math.min(SHOT_MAX_W, sw);
      const outH = Math.round(sh * (outW / sw));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(outW);
      canvas.height = Math.max(1, outH);
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);

      // Outline the element itself inside the wider crop.
      const k = canvas.width / sw;
      const bx = (r.left - padX < 0 ? r.left : padX) * scale * k;
      const by = (r.top - padY < 0 ? r.top : padY) * scale * k;
      ctx.strokeStyle = "#0099ff";
      ctx.lineWidth = 2;
      ctx.strokeRect(bx, by, r.width * scale * k, r.height * scale * k);

      return canvas.toDataURL("image/jpeg", 0.72);
    } catch {
      if (S.root) S.root.style.visibility = "";
      return "";
    }
  }

  /* ── composer ── */
  function closePopovers() {
    S.shadow.getElementById("popover-host").innerHTML = "";
  }
  function openComposer(at) {
    closePopovers();
    const host = S.shadow.getElementById("popover-host");
    const div = document.createElement("div");
    div.className = "popover composer";
    positionPopover(div, at.x, at.y);
    div.innerHTML = `
      <div id="c-text" class="composer-input" contenteditable="true" data-placeholder="Leave a comment…"></div>
      <div id="c-mentions" class="mentions" hidden></div>
      <div class="row">
        <select id="c-sev">${SEVERITIES.map((s) => `<option value="${s.id}">${s.label}</option>`).join("")}</select>
        <span class="flex"></span>
        <button class="btn ghost" id="c-cancel">Cancel</button>
        <button class="btn blue" id="c-save">Comment</button>
      </div>`;
    host.appendChild(div);
    const ta = div.querySelector("#c-text");
    setTimeout(() => ta.focus(), 30);
    const { expand } = attachMentions(ta, div.querySelector("#c-mentions"));
    div.querySelector("#c-cancel").addEventListener("click", closePopovers);
    div.querySelector("#c-save").addEventListener("click", async () => {
      const comment = expand(getContentText(ta).trim());
      if (!comment) return;
      const btn = div.querySelector("#c-save");
      btn.disabled = true;
      btn.textContent = "Saving…";
      try {
        const shot = await captureRegion(at.selector);
        const { pin } = await api(`/projects/${S.project.id}/pins`, {
          method: "POST",
          body: JSON.stringify({
            pageUrl: location.href,
            selector: at.selector,
            xr: at.xr, yr: at.yr,
            comment,
            severity: div.querySelector("#c-sev").value,
            viewport: window.innerWidth + "x" + window.innerHeight,
            device: window.innerWidth < 500 ? "phone" : window.innerWidth < 900 ? "tablet" : "desktop",
            shot,
          }),
        });
        S.pins.push(pin);
        closePopovers();
        renderPins();
        renderPanel();
      } catch (err) {
        btn.disabled = false;
        btn.textContent = "Comment";
        toast("Could not save: " + err.message);
      }
    });
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        div.querySelector("#c-save").click();
      }
      if (e.key === "Escape") closePopovers();
      e.stopPropagation();
    });
  }
  function positionPopover(div, pageX, pageY) {
    const w = 300;
    let left = pageX + 14;
    if (left + w > window.scrollX + window.innerWidth - 16) left = pageX - w - 14;
    div.style.left = Math.max(window.scrollX + 8, left) + "px";
    div.style.top = (pageY - 10) + "px";
  }

  /* ── @mentions ── */
  function memberList() {
    if (!S.project) return [];
    return [S.project.owner, ...(S.project.members || [])].filter(Boolean);
  }

  function getCaretTextBefore(el) {
    if (!el) return "";
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return el.value.slice(0, el.selectionStart);
    }
    const sel = (S.shadow && S.shadow.getSelection ? S.shadow.getSelection() : null) || window.getSelection();
    if (!sel || !sel.rangeCount) return el.textContent || "";
    const range = sel.getRangeAt(0);
    const container = range.startContainer;
    if (container.nodeType === Node.TEXT_NODE) {
      return container.nodeValue.slice(0, range.startOffset);
    }
    return el.textContent || "";
  }

  function getContentText(el) {
    if (!el) return "";
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return el.value;
    }
    let res = "";
    function walk(n) {
      if (n.nodeType === Node.TEXT_NODE) {
        res += n.nodeValue;
      } else if (n.nodeType === Node.ELEMENT_NODE) {
        if (n.classList.contains("mkmention-pill") && n.dataset.m) {
          res += "@" + n.dataset.m;
        } else if (n.tagName === "BR") {
          res += "\n";
        } else if (n.tagName === "DIV" || n.tagName === "P") {
          if (res && !res.endsWith("\n")) res += "\n";
          for (const c of n.childNodes) walk(c);
        } else {
          for (const c of n.childNodes) walk(c);
        }
      }
    }
    for (const c of el.childNodes) walk(c);
    return res;
  }

  function insertPill(el, fullEmail) {
    const handle = localPart(fullEmail);
    const sel = (S.shadow && S.shadow.getSelection ? S.shadow.getSelection() : null) || window.getSelection();
    if (!sel || !sel.rangeCount) return;
    const range = sel.getRangeAt(0);
    let node = range.startContainer;
    let offset = range.startOffset;

    if (node.nodeType !== Node.TEXT_NODE) {
      const textNode = document.createTextNode("@" + handle + "\u00A0");
      el.appendChild(textNode);
      node = textNode;
      offset = textNode.nodeValue.length;
    }

    const text = node.nodeValue;
    const before = text.slice(0, offset);
    const atIdx = before.lastIndexOf("@");
    if (atIdx !== -1) {
      const pre = text.slice(0, atIdx);
      const post = text.slice(offset);

      const pill = document.createElement("span");
      pill.className = "mkmention-pill";
      pill.contentEditable = "false";
      pill.dataset.m = fullEmail;
      pill.textContent = "@" + handle;

      const space = document.createTextNode("\u00A0");
      const parent = node.parentNode;

      const preNode = document.createTextNode(pre);
      const postNode = document.createTextNode(post);

      parent.insertBefore(preNode, node);
      parent.insertBefore(pill, node);
      parent.insertBefore(space, node);
      parent.insertBefore(postNode, node);
      parent.removeChild(node);

      const newRange = document.createRange();
      newRange.setStartAfter(space);
      newRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(newRange);
    }
  }

  // Returns { paint, expand }. `expand` turns short @handles typed back into full
  // @email addresses for storage — call it on save.
  function attachMentions(el, box) {
    const handleMap = new Map();
    for (const e of memberList()) {
      const lp = localPart(e).toLowerCase();
      if (lp && !handleMap.has(lp)) handleMap.set(lp, e);
    }
    const handles = [...handleMap.keys()];
    const handleRe = handles.length
      ? new RegExp("@(" + handles.map(escapeRe).join("|") + ")(?![\\w.@%+-])", "gi")
      : null;
    const expand = (t) => {
      const text = (typeof t === "string" ? t : getContentText(el));
      return handleRe ? text.replace(handleRe, (m, h) => "@" + (handleMap.get(h.toLowerCase()) || h)) : text;
    };
    const paint = () => {};

    box.addEventListener("mousedown", (ev) => {
      const b = ev.target.closest("button[data-m]");
      if (!b) return;
      ev.preventDefault();
      ev.stopPropagation();

      if (el.isContentEditable) {
        insertPill(el, b.dataset.m);
      } else {
        const pos = el.selectionStart;
        const before = el.value.slice(0, pos).replace(/@[a-zA-Z0-9._%+-]*$/, "@" + localPart(b.dataset.m) + " ");
        el.value = before + el.value.slice(pos);
      }

      S.suppressClickUntil = Date.now() + 500;
      setTimeout(() => { box.hidden = true; }, 0);
      el.focus();
    });

    const checkMentions = () => {
      const upto = getCaretTextBefore(el);
      const m = upto.match(/@([a-zA-Z0-9._%+-]*)$/);
      if (!m) { box.hidden = true; return; }
      const q = m[1].toLowerCase();
      const hits = [];
      for (const e of memberList()) {
        if (e.toLowerCase().includes(q)) hits.push(e);
        if (hits.length === 5) break;
      }
      if (!hits.length) { box.hidden = true; return; }
      box.innerHTML = hits.map((e) => `<button data-m="${esc(e)}">${esc(e)}</button>`).join("");
      box.hidden = false;
    };

    el.addEventListener("input", checkMentions);
    el.addEventListener("keyup", checkMentions);

    el.addEventListener("blur", () => setTimeout(() => { box.hidden = true; }, 150));
    return { paint, expand };
  }

  /* ── pins ── */
  let pinRaf = 0;
  function schedulePins() {
    if (pinRaf) return;
    pinRaf = requestAnimationFrame(() => { pinRaf = 0; renderPins(); });
  }
  function pagePins() {
    // pins for this page only (project can span many pages)
    return S.pins.filter((h) => {
      try { return new URL(h.pageUrl).pathname === location.pathname; } catch { return false; }
    });
  }
  function renderPins() {
    // Browse mode hides the pin layer, but scroll/resize/ResizeObserver keep
    // firing — and browse mode is exactly when the user scrolls the page. Skip
    // the per-pin querySelector + rebuild while nothing is on screen;
    // setCommentMode repaints when the layer comes back.
    if (!S.shadow || !S.commentMode) return;
    const wrap = S.shadow.getElementById("pins");
    const list = pagePins();
    wrap.innerHTML = list.map((h, i) => {
      const pos = resolvePin(h);
      if (!pos) return "";
      const sev = sevOf(h);
      return `<button class="pin ${h.status === "resolved" ? "resolved" : ""}" data-hid="${h.id}"
        style="left:${pos.x}px;top:${pos.y}px;background:${sev.color}">${i + 1}</button>`;
    }).join("");
    wrap.querySelectorAll(".pin").forEach((el) =>
      el.addEventListener("click", (e) => { e.stopPropagation(); openThread(el.dataset.hid); })
    );
  }

  /* ── thread popover ── */
  function openThread(hid) {
    const h = S.pins.find((x) => x.id === hid);
    if (!h) return;
    closePopovers();
    const pos = resolvePin(h) || { x: window.scrollX + 100, y: window.scrollY + 100 };
    const host = S.shadow.getElementById("popover-host");
    const sev = sevOf(h);
    const div = document.createElement("div");
    div.className = "popover thread";
    positionPopover(div, pos.x, pos.y);
    const members = memberList();
    div.innerHTML = `
      <div class="t-head">
        <label class="resolve"><input type="checkbox" id="t-resolve" ${h.status === "resolved" ? "checked" : ""}/> Resolve</label>
        <span class="flex"></span>
        <button class="x" id="t-del" title="Delete comment">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
        <button class="x" id="t-close" title="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="t-controls">
        <select id="t-sev">${SEVERITIES.map((s) => `<option value="${s.id}" ${s.id === h.severity ? "selected" : ""}>${s.label}</option>`).join("")}</select>
        <select id="t-assignee">
          <option value="">Assign…</option>
          ${members.map((m) => `<option value="${esc(m)}" ${h.assignee === m ? "selected" : ""}>${esc(m.split("@")[0])}</option>`).join("")}
        </select>
      </div>
      <div class="t-body">
        <div class="cmt"><span class="cav" style="background:${avatarColor(h.createdBy)}">${esc(initials(h.createdBy))}</span>
          <div class="cbub"><b>${esc((h.createdBy || "").split("@")[0])}</b>${renderText(h.comment)}</div></div>
        ${h.hasShot ? `<div class="t-shot-wrap" id="t-shot-wrap">
          <img class="t-shot" id="t-shot" alt="Screenshot of the commented element" />
          <span class="t-shot-hint">Click to expand</span>
        </div>` : ""}
        ${(h.comments || []).map((c) => `
          <div class="cmt"><span class="cav" style="background:${avatarColor(c.by || c.byName)}">${esc(initials(c.byName || c.by))}</span>
            <div class="cbub"><b>${esc(c.byName || c.by.split("@")[0])}</b>${renderText(c.text)}</div></div>`).join("")}
      </div>
      <div class="t-foot">
        <div id="t-reply" class="composer-input" contenteditable="true" data-placeholder="Reply…"></div>
        <div id="t-mentions" class="mentions" hidden></div>
        <button class="btn blue" id="t-send">Send</button>
      </div>`;
    host.appendChild(div);

    div.querySelector("#t-close").addEventListener("click", closePopovers);
    const shotEl = div.querySelector("#t-shot");
    if (shotEl) {
      api(`/projects/${S.project.id}/pins/${h.id}/shot`)
        .then((d) => {
          const wrap = div.querySelector("#t-shot-wrap");
          if (!d.shot) { if (wrap) wrap.remove(); return; }
          shotEl.src = d.shot;
          shotEl.addEventListener("click", (e) => { e.stopPropagation(); openLightbox(d.shot); });
        })
        .catch(() => { const w = div.querySelector("#t-shot-wrap"); if (w) w.remove(); });
    }
    div.querySelector("#t-sev").addEventListener("change", async (e) => {
      h.severity = e.target.value;
      renderPins(); renderPanel();
      try { await api(`/projects/${S.project.id}/pins/${h.id}`, { method: "PATCH", body: JSON.stringify({ severity: h.severity }) }); } catch {}
    });
    div.querySelector("#t-assignee").addEventListener("change", async (e) => {
      h.assignee = e.target.value;
      renderPanel();
      try { await api(`/projects/${S.project.id}/pins/${h.id}`, { method: "PATCH", body: JSON.stringify({ assignee: h.assignee }) }); } catch {}
    });
    div.querySelector("#t-resolve").addEventListener("change", async (e) => {
      h.status = e.target.checked ? "resolved" : "active";
      renderPins(); renderPanel();
      try { await api(`/projects/${S.project.id}/pins/${h.id}`, { method: "PATCH", body: JSON.stringify({ status: h.status }) }); } catch {}
    });
    const delBtn = div.querySelector("#t-del");
    let armed = false, armTimer = null, delLabel = delBtn.textContent;
    delBtn.addEventListener("click", async () => {
      // Two-step confirm in place of a blocking browser dialog: first click
      // arms, second (within 3s) deletes.
      if (!armed) {
        armed = true;
        delBtn.textContent = "Confirm delete?";
        delBtn.style.color = "#e5484d";
        armTimer = setTimeout(() => { armed = false; delBtn.textContent = delLabel; delBtn.style.color = ""; }, 3000);
        return;
      }
      clearTimeout(armTimer);
      const idx = S.pins.findIndex((x) => x.id === h.id);
      if (idx === -1) return;
      const [removed] = S.pins.splice(idx, 1);
      closePopovers();
      renderPins(); renderPanel();
      // hasShot lets the data layer skip a pointless round trip to the shots
      // worker for pins that never had a screenshot.
      try { await api(`/projects/${S.project.id}/pins/${h.id}`, { method: "DELETE", body: JSON.stringify({ hasShot: !!h.hasShot }) }); }
      catch { S.pins.splice(idx, 0, removed); renderPins(); renderPanel(); toast("Delete failed"); }
    });
    const ta = div.querySelector("#t-reply");
    const { expand } = attachMentions(ta, div.querySelector("#t-mentions"));
    const send = async () => {
      const text = expand(getContentText(ta).trim());
      if (!text) return;
      ta.innerHTML = "";
      try {
        const { comment } = await api(`/projects/${S.project.id}/pins/${h.id}/comments`, {
          method: "POST", body: JSON.stringify({ text }),
        });
        h.comments = h.comments || [];
        h.comments.push(comment);
        div.querySelector(".t-body").insertAdjacentHTML("beforeend",
          `<div class="cmt"><span class="cav" style="background:${avatarColor(comment.by || comment.byName)}">${esc(initials(comment.byName))}</span>
            <div class="cbub"><b>${esc(comment.byName)}</b>${renderText(comment.text)}</div></div>`);
        renderPanel();
      } catch {}
    };
    div.querySelector("#t-send").addEventListener("click", send);
    ta.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
      if (e.key === "Escape") closePopovers();
      e.stopPropagation();
    });
  }

  /* ── panel ── */
  function setPanelFabIcon() {
    const btn = S.shadow.getElementById("d-panel");
    btn.innerHTML = S.panelOpen
      ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`
      : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`;
  }
  function togglePanel() {
    S.panelOpen = !S.panelOpen;
    const p = S.shadow.getElementById("panel");
    p.hidden = !S.panelOpen;
    setPanelFabIcon();
    if (S.panelOpen) renderPanel();
  }
  function renderPanel() {
    if (!S.panelOpen || !S.shadow) return;
    const p = S.shadow.getElementById("panel");
    const act = S.pins.filter((h) => h.status !== "resolved");
    const res = S.pins.filter((h) => h.status === "resolved");
    const list = S.tab === "active" ? act : res;
    let host = "";
    try { host = new URL(S.project.url && /^https?:/.test(S.project.url) ? S.project.url : "https://" + S.project.url).host.replace(/^www\./, ""); } catch {}
    p.innerHTML = `
      <div class="p-crumb">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        PROJECTS
      </div>
      <div class="p-head">
        <div class="p-titlebox">
          <div class="p-title">${esc(S.project.name)}</div>
          <span class="p-host">${esc(host || S.project.url || "")}
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="m6 9 6 6 6-6"/></svg>
          </span>
        </div>
        <button class="p-kebab" id="p-kebab" aria-label="Project menu">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </button>
      </div>
      <div class="p-tabs">
        <button class="p-tab ${S.tab === "active" ? "on" : ""}" data-tab="active">Active (${act.length})</button>
        <button class="p-tab ${S.tab === "resolved" ? "on" : ""}" data-tab="resolved">Resolved (${res.length})</button>
      </div>
      ${list.length ? `<div class="p-list">
        ${list.map((h) => `
          <button class="p-item" data-hid="${h.id}">
            <span class="p-dot" style="background:${sevOf(h).color}"></span>
            <span class="p-txt">${esc(h.comment)}</span>
            <span class="p-n">${1 + (h.comments || []).length}</span>
          </button>`).join("")}
      </div>` : `<div class="p-empty-wrap">
        <div class="p-illus">
          <span class="tr"></span>
          <span class="kn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span>
        </div>
        <div class="p-empty-big">${list.length} ${S.tab} pin</div>
        <div class="p-empty-sub">${S.tab === "active" ? `<button id="p-enable-comment">Switch to Comment View</button> to add one` : `Resolve a pin and it lands here`}</div>
      </div>`}
      <div id="p-menu" class="menu" hidden>
        <button id="pm-app">Open in Marko app</button>
        <button id="pm-copy">Copy project link</button>
        <button id="pm-details">Project details</button>
      </div>`;
    const crumb = p.querySelector(".p-crumb");
    crumb.style.cursor = "pointer";
    crumb.addEventListener("click", togglePanel);
    const enable = p.querySelector("#p-enable-comment");
    if (enable) enable.addEventListener("click", () => { setCommentMode(true); togglePanel(); });
    p.querySelectorAll(".p-tab").forEach((t) =>
      t.addEventListener("click", () => { S.tab = t.dataset.tab; renderPanel(); })
    );
    p.querySelectorAll(".p-item").forEach((el) =>
      el.addEventListener("click", () => {
        const h = S.pins.find((x) => x.id === el.dataset.hid);
        if (!h) return;
        const samePage = (() => { try { return new URL(h.pageUrl).pathname === location.pathname; } catch { return false; } })();
        if (!samePage && h.pageUrl) { location.href = h.pageUrl; return; }
        const pos = resolvePin(h);
        if (pos) window.scrollTo({ top: Math.max(0, pos.y - window.innerHeight / 2), behavior: "smooth" });
        setTimeout(() => openThread(h.id), 350);
      })
    );
    p.querySelector("#p-kebab").addEventListener("click", () => {
      const m = p.querySelector("#p-menu");
      m.hidden = !m.hidden;
    });
    p.querySelector("#pm-app").addEventListener("click", () => window.open(APP_URL + "#/p/" + S.project.id, "_blank"));
    p.querySelector("#pm-copy").addEventListener("click", copyLink);
    p.querySelector("#pm-details").addEventListener("click", () => {
      p.querySelector("#p-menu").hidden = true;
      openDetails();
    });
  }

  /* ── screenshot lightbox ── */
  function openLightbox(src) {
    const host = S.shadow.getElementById("popover-host");
    const lb = document.createElement("div");
    lb.className = "lightbox";
    lb.innerHTML = `
      <button class="lb-close" title="Close">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
      </button>
      <img alt="Screenshot of the commented element" />`;
    lb.querySelector("img").src = src;
    const close = () => { lb.remove(); document.removeEventListener("keydown", onKey, true); };
    const onKey = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    lb.addEventListener("click", close);
    document.addEventListener("keydown", onKey, true);
    host.appendChild(lb);
  }

  /* ── project details ── */
  function openDetails() {
    closePopovers();
    const pr = S.project;
    const people = [pr.owner, ...(pr.members || [])].filter(Boolean);
    let host = "";
    try { host = new URL(/^https?:/.test(pr.url) ? pr.url : "https://" + pr.url).host; } catch {}
    const host2 = S.shadow.getElementById("popover-host");
    const div = document.createElement("div");
    div.className = "sheet-wrap";
    div.innerHTML = `
      <div class="sheet">
        <div class="sheet-head">
          <b>Project details</b>
          <button class="x" id="pd-close" title="Close">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <dl class="sheet-rows">
          <dt>Name</dt><dd>${esc(pr.name)}</dd>
          <dt>Site</dt><dd>${host ? `<a href="${esc(pr.url)}" target="_blank" rel="noopener">${esc(host)}</a>` : "&mdash;"}</dd>
          ${pr.description ? `<dt>Description</dt><dd>${esc(pr.description)}</dd>` : ""}
          <dt>Owner</dt><dd>${esc(pr.owner)}</dd>
          <dt>Comments</dt><dd>${S.pins.length} total &middot; ${S.pins.filter((h) => h.status !== "resolved").length} active</dd>
        </dl>
        <div class="sheet-people">
          <span class="sheet-label">Team (${people.length})</span>
          <div class="sheet-avs">
            ${people.map((m) => `<span class="sheet-av" style="background:${avatarColor(m)}" title="${esc(m)}">${esc(initials(m))}</span>`).join("")}
          </div>
        </div>
        <button class="btn blue wide" id="pd-app">Open in Marko app</button>
      </div>`;
    host2.appendChild(div);
    const close = () => div.remove();
    div.querySelector("#pd-close").addEventListener("click", close);
    div.addEventListener("click", (e) => { if (e.target === div) close(); });
    div.querySelector("#pd-app").addEventListener("click", () => {
      window.open(APP_URL + "#/p/" + pr.id, "_blank");
      close();
    });
  }

  /* ── share + link ── */
  function openShare() {
    closePopovers();
    const host = S.shadow.getElementById("popover-host");
    const div = document.createElement("div");
    div.className = "popover share";
    div.style.left = (window.scrollX + 20) + "px";
    div.style.top = (window.scrollY + window.innerHeight - 260) + "px";
    div.innerHTML = `
      <b>Share "${esc(S.project.name)}"</b>
      <p class="hint">Teammates sign in with their own email and see every pin.</p>
      <input id="s-emails" placeholder="anna@team.com, erik@team.com" />
      <div class="row">
        <span class="flex status" id="s-status"></span>
        <button class="btn ghost" id="s-cancel">Close</button>
        <button class="btn blue" id="s-send">Invite</button>
      </div>`;
    host.appendChild(div);
    div.querySelector("#s-cancel").addEventListener("click", closePopovers);
    div.querySelector("#s-send").addEventListener("click", async () => {
      const emails = div.querySelector("#s-emails").value.split(",").map((s) => s.trim()).filter(Boolean);
      const st = div.querySelector("#s-status");
      if (!emails.length) { st.textContent = "Enter emails."; return; }
      st.textContent = "Inviting…";
      try {
        const { added, members } = await api(`/projects/${S.project.id}/invites`, {
          method: "POST", body: JSON.stringify({ emails }),
        });
        S.project.members = members;
        st.textContent = added.length ? "Invited " + added.length + "." : "Already members.";
      } catch (e) { st.textContent = "Failed: " + e.message; }
    });
  }
  async function copyLink() {
    try {
      await navigator.clipboard.writeText(APP_URL + "#/p/" + S.project.id);
      toast("Project link copied");
    } catch {
      toast("Copy failed");
    }
  }
  function toast(msg) {
    const host = S.shadow.getElementById("popover-host");
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    host.appendChild(t);
    setTimeout(() => t.remove(), 2200);
  }

  /* ── resolution pill ── */
  function renderResMenu() {
    const menu = S.shadow.getElementById("res-menu");
    menu.innerHTML = `
      <div class="r-head">Screen resolution</div>
      <button class="r-item r-plain" data-w="${window.screen.width}" data-h="${window.screen.height}">
        <span>My display</span><span class="r-dim">${window.screen.width} x ${window.screen.height}</span>
      </button>
      <button class="r-item r-plain" id="r-custom-toggle">
        <span>Custom</span>
        <svg class="r-caret" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="r-custom" id="r-custom" hidden>
        <label>Width<input id="r-w" type="number" min="320" max="3840" value="${window.innerWidth}" /></label>
        <label>Height<input id="r-h" type="number" min="400" max="2160" value="${window.innerHeight}" /></label>
        <button class="btn blue" id="r-apply">Apply</button>
      </div>
      ${RESOLUTIONS.map((g) => `
        <div class="r-group">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${GROUP_ICONS[g.icon]}</svg>
          ${g.group}
        </div>
        ${g.items.map(([label, w, h]) => `
          <button class="r-item" data-w="${w}" data-h="${h}">
            <span>${label}</span><span class="r-dim">${w} x ${h}</span>
          </button>`).join("")}`).join("")}`;

    menu.querySelectorAll(".r-item[data-w]").forEach((el) =>
      el.addEventListener("click", () => {
        applyResolution(Number(el.dataset.w), Number(el.dataset.h));
        menu.hidden = true;
      })
    );
    const toggle = menu.querySelector("#r-custom-toggle");
    toggle.addEventListener("click", () => {
      const box = menu.querySelector("#r-custom");
      box.hidden = !box.hidden;
      toggle.classList.toggle("open", !box.hidden);
    });
    menu.querySelector("#r-apply").addEventListener("click", () => {
      applyResolution(Number(menu.querySelector("#r-w").value), Number(menu.querySelector("#r-h").value));
      menu.hidden = true;
    });
  }

  function applyResolution(width, height) {
    if (!Number.isFinite(width) || !Number.isFinite(height)) return;
    chrome.runtime.sendMessage({
      type: "MARKO_RESIZE_WINDOW",
      width: Math.max(320, Math.round(width)),
      height: Math.max(400, Math.round(height)),
    });
  }

  function toggleResMenu() {
    const menu = S.shadow.getElementById("res-menu");
    menu.hidden = !menu.hidden;
  }
  function updateResLabel() {
    const btn = S.shadow && S.shadow.getElementById("res-btn");
    if (btn) btn.childNodes[0].nodeValue = window.innerWidth + " x " + window.innerHeight + " ";
    // keep the Custom inputs showing the live size until the user edits them
    const w = S.shadow && S.shadow.getElementById("r-w");
    const h = S.shadow && S.shadow.getElementById("r-h");
    const box = S.shadow && S.shadow.getElementById("r-custom");
    if (w && h && box && box.hidden) { w.value = window.innerWidth; h.value = window.innerHeight; }
  }

  /* ── keep pins correct on SPA navigation and layout shifts ── */
  let lastHref = location.href;
  let locTimer = 0;
  function watchLocation() {
    clearInterval(locTimer);
    locTimer = setInterval(() => {
      if (!S.active) { clearInterval(locTimer); return; }
      if (location.href === lastHref) return;
      lastHref = location.href;
      closePopovers();
      renderPins();
      renderPanel();
    }, 600);
  }
  let layoutObserver = null;
  function watchLayout() {
    // Late-loading images and lazy content move anchors around.
    if (typeof ResizeObserver === "undefined") return;
    layoutObserver = new ResizeObserver(schedulePins);
    layoutObserver.observe(document.documentElement);
  }

  /* ── lifecycle ── */
  async function start(project, opts = {}) {
    if (S.active) return;
    S.settings = await getSettings();
    if (!MarkoDB.isValid(S.settings)) return;
    S.project = project || S.settings.activeProject;
    if (!S.project) return;
    S.active = true;
    S.commentMode = opts.comment !== false;
    try {
      const data = await api("/projects/" + S.project.id);
      S.project = data.project;
      S.pins = data.pins || [];
    } catch {
      S.pins = [];
    }
    mount();
    renderPins();
    document.addEventListener("click", onPageClick, true);
    document.addEventListener("mousemove", onPageMove, true);
    window.addEventListener("scroll", schedulePins, true);
    window.addEventListener("resize", onWindowResize);
    watchLocation();
    watchLayout();
  }
  function stop() {
    if (!S.active) return;
    S.active = false;
    S.panelOpen = false;
    document.documentElement.style.cursor = "";
    clearInterval(locTimer);
    if (layoutObserver) { layoutObserver.disconnect(); layoutObserver = null; }
    MarkoDB.releaseShots();
    unmount();
  }

  const CSS_TEXT = `
    :host { all: initial; }
    /* The hidden attribute must beat any display rule below, otherwise
       hiding the dock in browse mode silently does nothing. */
    [hidden] { display: none !important; }
    * { box-sizing: border-box; font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; letter-spacing: -0.01em; }
    button { cursor: pointer; border: 0; background: none; font: inherit; color: inherit; }

    #hover-box {
      position: absolute; z-index: 2147483644; pointer-events: none;
      border: 2px solid #4da3f7; border-radius: 4px;
      background: rgba(77,163,247,.10);
      box-shadow: 0 0 0 1px rgba(255,255,255,.6);
      transition: left .05s linear, top .05s linear, width .05s linear, height .05s linear;
    }

    #dock {
      position: fixed; left: 22px; bottom: 22px; z-index: 2147483646;
      display: flex; align-items: center; gap: 14px;
    }
    .fab {
      position: relative;
      width: 58px; height: 58px; border-radius: 50%; background: #fff; color: #1c222e;
      box-shadow: 0 4px 10px rgba(10,14,30,.14), 0 12px 34px rgba(10,14,30,.18);
      display: flex; align-items: center; justify-content: center;
      transition: transform .3s ease-out, box-shadow .25s ease;
    }
    .fab:hover { transform: translateY(-2px); box-shadow: 0 6px 14px rgba(10,14,30,.16), 0 16px 40px rgba(10,14,30,.22); }
    .fab.big { width: 62px; height: 62px; }
    .fab svg { width: 22px; height: 22px; }
    .fab.big svg { width: 25px; height: 25px; }
    .avatar {
      position: absolute; left: -4px; bottom: -4px;
      width: 24px; height: 24px; border-radius: 50%; background: #17b26a; color: #fff;
      font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center;
      border: 2.5px solid #fff; overflow: hidden;
    }
    .avatar img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; display: block; }

    #mode-toggle {
      position: fixed; left: 50%; transform: translateX(-50%); bottom: 26px; z-index: 2147483646;
      cursor: pointer;
    }
    #mode-toggle .track {
      display: block; width: 76px; height: 42px; border-radius: 999px; background: #e2e6ee;
      position: relative; transition: background .18s;
      box-shadow: 0 4px 10px rgba(10,14,30,.14), 0 12px 34px rgba(10,14,30,.18);
    }
    #mode-toggle.on .track { background: #7cb8f8; }
    #mode-toggle .knob {
      position: absolute; top: 3px; left: 3px; width: 36px; height: 36px; border-radius: 50%;
      background: #fff; color: #2f8bf0; display: flex; align-items: center; justify-content: center;
      transition: left .18s cubic-bezier(.34,1.4,.64,1);
      box-shadow: 0 2px 8px rgba(10,14,30,.28);
    }
    #mode-toggle .knob svg { width: 16px; height: 16px; }
    #mode-toggle.on .knob { left: 37px; }

    #res-pill { position: fixed; top: 16px; right: 18px; z-index: 2147483646; }
    #res-btn {
      background: #fff; border-radius: 999px; padding: 9px 16px; font-size: 13px; font-weight: 600;
      color: #2b3242; box-shadow: 0 6px 24px rgba(10,14,30,.22);
      display: inline-flex; align-items: center; gap: 7px;
    }
    #res-menu {
      position: absolute; right: 0; top: 44px; width: 290px; max-height: 60vh; overflow-y: auto;
      background: #fff; border-radius: 14px; box-shadow: 0 24px 60px rgba(10,14,30,.3); padding: 10px 0;
    }
    .r-head { font-size: 11px; letter-spacing: .8px; text-transform: uppercase; color: #7f8698; padding: 8px 18px; font-weight: 700; }
    .r-group {
      display: flex; align-items: center; gap: 8px;
      font-size: 13px; font-weight: 700; color: #2b3242;
      padding: 12px 18px 4px; border-top: 1px solid #f0f0f0; margin-top: 4px;
    }
    .r-item {
      display: flex; justify-content: space-between; width: 100%;
      padding: 8px 18px; font-size: 13.5px; color: #3c4356;
    }
    .r-item:hover { background: #f2f5fa; }
    .r-plain { color: #2b3242; font-weight: 500; }
    .r-caret { transition: transform .15s; }
    #r-custom-toggle.open .r-caret { transform: rotate(180deg); }
    .r-custom { display: flex; gap: 8px; align-items: flex-end; padding: 8px 18px 12px; }
    .r-custom label { flex: 1; font-size: 11.5px; color: #7f8698; display: flex; flex-direction: column; gap: 4px; }
    .r-custom input {
      width: 100%; border: 1px solid #e3e6ec; border-radius: 8px; padding: 7px 9px;
      font: 13px -apple-system, sans-serif; color: #000000; outline: 0;
    }
    .r-custom input:focus { border-color: #0099ff; }
    .r-custom .btn { padding: 7px 14px; }
    .r-dim { color: #7f8698; }

    .pin {
      position: absolute; z-index: 2147483645; transform: translate(-50%, -100%);
      min-width: 26px; height: 26px; border-radius: 13px 13px 13px 3px; color: #fff;
      font-size: 12px; font-weight: 700; padding: 0 6px;
      box-shadow: 0 4px 14px rgba(10,14,30,.3); border: 2px solid #fff;
    }
    .pin.resolved { opacity: .45; }

    .popover {
      position: absolute; z-index: 2147483646; width: 316px;
      background: #fff; border-radius: 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,.05), 0 20px 50px rgba(0,0,0,.16);
      padding: 14px; color: #000000;
    }
    .popover textarea, .popover input {
      width: 100%; border: 0; box-shadow: inset 0 0 0 1px #e3e3e3;
      border-radius: 12px; padding: 10px 13px;
      font: 13.5px/1.4 -apple-system, sans-serif; outline: 0; resize: vertical; color: #000000; background: #fff;
    }
    .popover textarea:focus, .popover input:focus { box-shadow: inset 0 0 0 2px #0099ff; }
    .popover .composer-input {
      width: 100%; border: 0; box-shadow: inset 0 0 0 1px #e3e3e3;
      border-radius: 12px; padding: 10px 13px; min-height: 52px; max-height: 180px; overflow-y: auto;
      font: 13.5px/1.4 -apple-system, sans-serif; outline: 0; color: #000000; background: #fff;
      white-space: pre-wrap; word-break: break-word;
    }
    .popover .composer-input:focus { box-shadow: inset 0 0 0 2px #0099ff; }
    .popover .composer-input:empty:before {
      content: attr(data-placeholder); color: #9aa3b2; pointer-events: none;
    }
    .mkmention-pill {
      color: #0099ff; background: #e6f2ff; border-radius: 4px; padding: 1px 5px;
      font-weight: 600; display: inline-block; user-select: all; margin: 0 1px;
    }
    .popover .row { display: flex; align-items: center; gap: 8px; margin-top: 10px; }
    .popover select {
      border: 0; box-shadow: inset 0 0 0 1px #e3e3e3;
      border-radius: 10px; padding: 7px 10px; font-size: 12.5px;
      background: #fff; color: #3c4356; outline: 0;
    }
    .flex { flex: 1; }
    .btn { border-radius: 100px; padding: 9px 16px; font-size: 13px; font-weight: 600; transition: background .25s ease, transform .3s ease-out; }
    .btn.blue { background: #000000; color: #fff; }
    .btn.blue:hover { background: #1c1f26; transform: translateY(-1px); }
    .btn.blue:disabled { opacity: .6; cursor: default; }
    .btn.ghost { color: #6a7183; }
    .btn.ghost:hover { background: #f2f5fa; }
    .x { color: #7b828e; font-size: 14px; padding: 4px 6px; border-radius: 6px; }
    .x:hover { background: #f2f5fa; color: #000000; }

    .mentions {
      background: #fff; border: 1px solid #e3e6ec; border-radius: 10px; margin-top: 4px;
      box-shadow: 0 10px 30px rgba(10,14,30,.15); overflow: hidden;
    }
    .mentions button { display: block; width: 100%; text-align: left; padding: 8px 12px; font-size: 13px; }
    .mentions button:hover { background: #f2f5fa; }
    .mkmention { color: #0099ff; font-weight: 600; background: #e6f2ff; border-radius: 4px; padding: 0 3px; }

    .thread .t-head {
      display: flex; align-items: center; gap: 4px; margin: -2px -2px 8px;
      padding-bottom: 8px; border-bottom: 1px solid #f0f0f0;
    }
    .thread .t-controls { display: flex; gap: 8px; margin-bottom: 10px; }
    .thread .t-controls select { flex: 1; min-width: 0; }
    .thread .resolve { font-size: 12px; color: #3c4356; display: flex; align-items: center; gap: 5px; white-space: nowrap; }
    .thread #t-del:hover { background: #fdeaea; color: #e5484d; }
    .thread .t-body { max-height: 240px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; margin-bottom: 8px; }
    .cmt { display: flex; gap: 8px; }
    .cav {
      width: 24px; height: 24px; border-radius: 50%; background: #0099ff; color: #fff;
      font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .cbub { background: #f7f7f7; border-radius: 11px; padding: 9px 12px; font-size: 13px; flex: 1; }
    .t-shot-wrap { position: relative; margin: 2px 0 4px; }
    .t-shot {
      display: block; width: 100%; border-radius: 9px; border: 1px solid #e3e6ec;
      cursor: zoom-in; background: #f7f8fb;
    }
    .t-shot-hint {
      position: absolute; right: 7px; bottom: 7px;
      background: rgba(0,0,0,.62); color: #fff; border-radius: 999px;
      padding: 3px 9px; font-size: 10.5px; pointer-events: none;
    }
    .lightbox {
      position: fixed; inset: 0; z-index: 2147483647; background: rgba(6,9,16,.88);
      display: flex; align-items: center; justify-content: center; padding: 40px;
      cursor: zoom-out;
    }
    .lightbox img { max-width: 100%; max-height: 100%; border-radius: 10px; }
    .lb-close {
      position: absolute; top: 20px; right: 24px; color: #fff;
      width: 38px; height: 38px; border-radius: 50%; background: rgba(255,255,255,.14);
      display: flex; align-items: center; justify-content: center;
    }
    .lb-close:hover { background: rgba(255,255,255,.24); }
    .cbub b { display: block; font-size: 11.5px; margin-bottom: 2px; }
    .thread .t-foot { display: flex; gap: 8px; align-items: flex-end; }
    .thread .t-foot textarea { flex: 1; }

    .share b { font-size: 14px; display: block; margin-bottom: 4px; }
    .share .hint { font-size: 12px; color: #7f8698; margin: 0 0 10px; }
    .share .status { font-size: 12px; color: #16a34a; }

    #panel {
      position: fixed; top: 0; left: 0; bottom: 0; width: 400px; max-width: 92vw; z-index: 2147483645;
      background: #fff; box-shadow: 18px 0 50px rgba(10,14,30,.16);
      display: flex; flex-direction: column; color: #000000;
      padding-bottom: 96px;
    }
    .p-crumb {
      display: flex; align-items: center; gap: 7px; padding: 18px 20px 6px;
      font-size: 12px; font-weight: 700; letter-spacing: 1px; color: #3c4356;
    }
    .p-crumb svg { width: 14px; height: 14px; }
    .p-head { display: flex; align-items: flex-start; gap: 6px; padding: 8px 20px 12px; }
    .p-titlebox { flex: 1; min-width: 0; }
    .p-title { font-weight: 700; font-size: 20px; letter-spacing: -.3px; color: #1c222e;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-host { display: inline-flex; align-items: center; gap: 5px; margin-top: 2px;
      font-size: 14px; color: #7f8698; }
    .p-host svg { width: 12px; height: 12px; }
    .p-kebab {
      width: 34px; height: 34px; border-radius: 9px; background: #f2f4f8; color: #7f8698;
      display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .p-kebab:hover { background: #e8ebf2; color: #1c222e; }
    .p-tabs { display: flex; border-bottom: 1px solid #f0f0f0; }
    .p-tab { flex: 1; padding: 12px; font-size: 15px; font-weight: 600; color: #7f8698;
      border-bottom: 3px solid transparent; margin-bottom: -1px; }
    .p-tab.on { color: #2f8bf0; border-color: #2f8bf0; }
    .p-list { flex: 1; overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 6px; }
    .p-empty-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; padding-top: 70px; gap: 6px; }
    .p-illus { position: relative; width: 110px; height: 64px; margin-bottom: 12px; }
    .p-illus .tr { position: absolute; left: 0; top: 12px; width: 84px; height: 40px; border-radius: 999px; background: #e9edf3; }
    .p-illus .kn { position: absolute; left: 52px; top: 6px; width: 52px; height: 52px; border-radius: 50%; background: #fff;
      box-shadow: 0 6px 18px rgba(10,14,30,.16); display: flex; align-items: center; justify-content: center; color: #4da3f7; }
    .p-illus .kn svg { width: 20px; height: 20px; }
    .p-empty-big { font-size: 18px; font-weight: 600; color: #5b6272; }
    .p-empty-sub { font-size: 14.5px; color: #a3aab8; }
    .p-empty-sub button { color: #4da3f7; font-weight: 600; }
    .p-item {
      display: flex; align-items: flex-start; gap: 9px; text-align: left;
      padding: 12px 14px; border-radius: 16px; border: 0;
      box-shadow: inset 0 0 0 1px #f0f0f0; width: 100%;
      transition: background .25s ease;
    }
    .p-item:hover { background: #f4f7fd; box-shadow: inset 0 0 0 1px #d9e3fb; }
    .p-dot { width: 9px; height: 9px; border-radius: 50%; margin-top: 4px; flex-shrink: 0; }
    .p-txt { flex: 1; font-size: 13px; color: #2b3242; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
    .p-n { font-size: 11.5px; color: #7f8698; background: #f2f4f8; border-radius: 6px; padding: 1px 7px; }
    .menu {
      position: absolute; top: 46px; right: 12px; background: #fff; border-radius: 12px;
      box-shadow: 0 18px 50px rgba(10,14,30,.2); padding: 6px; min-width: 190px; z-index: 5;
    }
    .menu button { display: block; width: 100%; text-align: left; padding: 9px 12px; border-radius: 8px; font-size: 13.5px; }
    .menu button:hover { background: #f2f5fa; }

    .sheet-wrap {
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(9,12,20,.5); backdrop-filter: blur(4px);
      display: flex; align-items: center; justify-content: center; padding: 24px;
    }
    .sheet {
      width: min(400px, 100%); background: #fff; border-radius: 30px; padding: 26px;
      box-shadow: 0 30px 70px rgba(10,14,30,.4); color: #000000;
    }
    .sheet-head { display: flex; align-items: center; margin-bottom: 14px; }
    .sheet-head b { flex: 1; font-size: 16px; }
    .sheet-rows { display: grid; grid-template-columns: 92px 1fr; gap: 8px 12px; margin-bottom: 16px; }
    .sheet-rows dt { font-size: 12.5px; color: #7f8698; }
    .sheet-rows dd { font-size: 13.5px; margin: 0; word-break: break-word; }
    .sheet-rows a { color: #0099ff; }
    .sheet-label { font-size: 12.5px; color: #7f8698; display: block; margin-bottom: 7px; }
    .sheet-people { margin-bottom: 16px; }
    .sheet-avs { display: flex; flex-wrap: wrap; gap: 6px; }
    .sheet-av {
      width: 28px; height: 28px; border-radius: 50%; background: #0099ff; color: #fff;
      font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center;
    }
    .btn.wide { width: 100%; justify-content: center; display: flex; }

    .toast {
      position: fixed; bottom: 84px; left: 50%; transform: translateX(-50%);
      background: #000000; color: #fff; font-size: 13px; padding: 9px 16px; border-radius: 999px;
      box-shadow: 0 10px 30px rgba(0,0,0,.35); z-index: 2147483647;
    }
  `;

  window.__MARKO_REVIEW__ = {
    start,
    stop,
    setCommentMode,
    get active() { return S.active; },
    get commentMode() { return S.commentMode; },
  };
})();
