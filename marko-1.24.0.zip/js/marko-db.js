"use strict";
/**
 * Marko extension data layer (Supabase, no SDK).
 *
 * Talks to Supabase's REST (PostgREST), RPC, auth, and the R2 shots worker
 * with plain fetch, so it stays tiny enough to inject into every page as a
 * content script. Exposes MarkoDB.api(path, opts) with the SAME paths and
 * return shapes the old Cloudflare Worker used, so the popup/dock/background
 * call sites barely change.
 *
 * Only the routes the extension actually calls live here; the web app has its
 * own independent layer (marko-site/marko-data.js) and does not share this
 * file, so unused branches are dead weight on every page load.
 *
 * The session is bridged in from the web sign-in (auth/callback.js) and kept
 * in chrome.storage under marko:settings as { sbAccess, sbRefresh, sbExp, user }.
 * Access tokens are refreshed transparently when close to expiry.
 */
(() => {
  const g = typeof self !== "undefined" ? self : window;
  if (g.MarkoDB) return;

  const SUPABASE_URL = "https://snzzbhllukfgqwsooyzl.supabase.co";
  const SUPABASE_KEY = "sb_publishable_Eql7htJAaY1v7QariGDn3Q_gnbkUGJb";
  const SHOTS_URL = "https://marko-shots.strativ.workers.dev";
  const REST = SUPABASE_URL + "/rest/v1";
  const AUTH = SUPABASE_URL + "/auth/v1";
  const SETTINGS_KEY = "marko:settings";

  // Marko's own pages are not review targets: the dock mounting on top of the
  // dashboard is confusing and lets you comment on the comments.
  //
  // Matched on host AND path, not host alone. strativ-dev.github.io serves the
  // dashboard, the marketing site, and every other repo in the org, so a
  // host-only rule also blocked pages that are perfectly good review targets.
  // The path list is the app surfaces only; the host keeps it from firing on an
  // unrelated site that happens to have its own /app.html.
  const OWN_HOSTS = ["strativ-dev.github.io"];
  const OWN_PATHS = /\/(app|reset)\.html$/i;
  function isOwnSurface(url) {
    let u;
    try { u = new URL(url); } catch { return false; }
    if (u.protocol === "chrome-extension:") return true;
    return OWN_HOSTS.includes(u.host) && OWN_PATHS.test(u.pathname);
  }

  async function getSettings() {
    const r = await chrome.storage.local.get(SETTINGS_KEY);
    return r[SETTINGS_KEY] || {};
  }
  async function setSettings(patch) {
    const s = await getSettings();
    Object.assign(s, patch);
    await chrome.storage.local.set({ [SETTINGS_KEY]: s });
    return s;
  }
  async function clearSession() {
    await setSettings({ sbAccess: null, sbRefresh: null, sbExp: 0, user: null });
  }
  function isValid(s) {
    return !!(s && s.sbAccess && (s.sbExp || 0) > Date.now() + 30_000);
  }

  // Supabase rotates refresh tokens, so two parallel refreshes race: the loser
  // gets a hard failure for a token the winner already spent. Single-flight so
  // concurrent callers (popup fires /notifications and /projects/find at once,
  // a pin save takes three tokens) share one POST and one settings write.
  let refreshing = null;
  function refresh() {
    refreshing ||= doRefresh().finally(() => { refreshing = null; });
    return refreshing;
  }
  async function doRefresh() {
    const s = await getSettings();
    if (!s.sbRefresh) { await clearSession(); throw new Error("unauthorized"); }
    const r = await fetch(AUTH + "/token?grant_type=refresh_token", {
      method: "POST",
      headers: { apikey: SUPABASE_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: s.sbRefresh }),
    });
    if (!r.ok) {
      // Only destroy the session if nobody else rotated it in the meantime and
      // the server actually rejected us — a 429/5xx must not sign the user out.
      const now = await getSettings();
      if (now.sbRefresh === s.sbRefresh && r.status >= 400 && r.status < 500) await clearSession();
      throw new Error("unauthorized");
    }
    const d = await r.json();
    await setSettings({
      sbAccess: d.access_token,
      sbRefresh: d.refresh_token,
      sbExp: (d.expires_at || 0) * 1000,
      user: {
        id: (d.user && d.user.id) || (s.user || {}).id,
        email: (d.user && d.user.email) || (s.user || {}).email,
        name: (d.user && d.user.user_metadata && (d.user.user_metadata.name || d.user.user_metadata.full_name)) || (s.user || {}).name,
        // Google's picture can rotate; re-adopt it on every refresh instead of
        // freezing whatever was captured at sign-in. Falls back to whatever
        // was already stored (e.g. the original callback.js bridge) so a
        // refresh from a provider with no avatar claim doesn't blank it out.
        avatar: (d.user && d.user.user_metadata && (d.user.user_metadata.avatar_url || d.user.user_metadata.picture)) || (s.user || {}).avatar || "",
      },
    });
    return d.access_token;
  }
  async function token() {
    const s = await getSettings();
    if (!s.sbAccess) throw new Error("unauthorized");
    if ((s.sbExp || 0) < Date.now() + 60_000) return await refresh();
    return s.sbAccess;
  }

  async function rest(path, { method = "GET", body, prefer } = {}) {
    const t = await token();
    const headers = { apikey: SUPABASE_KEY, Authorization: "Bearer " + t };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (prefer) headers["Prefer"] = prefer;
    const r = await fetch(REST + path, {
      method, headers, body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (r.status === 401) { await clearSession(); throw new Error("unauthorized"); }
    const txt = await r.text();
    let data = null; try { data = txt ? JSON.parse(txt) : null; } catch {}
    if (!r.ok) { const e = new Error((data && data.message) || ("http_" + r.status)); e.data = data; throw e; }
    return data;
  }
  // Row count without transferring rows: PostgREST answers a HEAD + count=exact
  // with the total in Content-Range ("*\/42"). Used wherever we only need "how
  // many", never the rows themselves.
  async function restCount(path) {
    const t = await token();
    const r = await fetch(REST + path, {
      method: "HEAD",
      headers: {
        apikey: SUPABASE_KEY, Authorization: "Bearer " + t,
        Prefer: "count=exact", Range: "0-0",
      },
    });
    if (r.status === 401) { await clearSession(); throw new Error("unauthorized"); }
    const cr = r.headers.get("Content-Range") || "";
    const n = Number(cr.split("/")[1]);
    return Number.isFinite(n) ? n : 0;
  }
  const one = (a) => (Array.isArray(a) ? a[0] : a);

  // ── shape mappers (identical to the web layer) ──
  const mapComment = (c) => ({ id: c.id, by: c.author_email, byName: c.author_name, text: c.text, at: c.created_at });
  // Comments come back already ordered (comments.order=created_at.asc on every
  // embed), so no client-side sort is needed.
  const mapPin = (h) => ({
    id: h.id, pageUrl: h.page_url, selector: h.selector, xr: h.xr, yr: h.yr,
    comment: h.comment, severity: h.severity, status: h.status, assignee: h.assignee,
    due: h.due, device: h.device, viewport: h.viewport, hasShot: h.has_shot,
    createdBy: h.created_by_email, createdAt: h.created_at,
    comments: (h.comments || []).map(mapComment),
  });
  const mapProject = (p) => ({
    id: p.id, name: p.name, url: p.url, description: p.description || "",
    owner: p.owner_email, members: (p.project_members || []).map((m) => m.email),
    archived: !!p.archived, shareToken: p.share_token, createdAt: p.created_at, updatedAt: p.updated_at,
  });
  // Only the columns mapProject reads — no point shipping every column of every
  // project across the wire on each page load.
  const PROJECT_COLS = "id,name,url,description,owner_email,archived,share_token,created_at,updated_at,project_members(email)";
  function hostOf(u) {
    const s = String(u || "").trim(); if (!s) return "";
    try { return new URL(/^https?:\/\//i.test(s) ? s : "https://" + s).host.replace(/^www\./i, "").toLowerCase(); }
    catch { return ""; }
  }

  async function uploadShot(pid, pinId, dataUrl) {
    const blob = await (await fetch(dataUrl)).blob();
    const r = await fetch(`${SHOTS_URL}/shot/${pid}/${pinId}`, {
      method: "PUT",
      headers: { Authorization: "Bearer " + (await token()), "Content-Type": blob.type || "image/png" },
      body: blob,
    });
    if (!r.ok) throw new Error("shot_upload_failed");
  }
  // Shots are written once and never change, so the blob URL is cached per pin:
  // reopening a thread reuses it instead of re-downloading the image and
  // leaking another object URL that nothing ever revokes.
  const shotCache = new Map();
  async function getShot(pid, pinId) {
    const key = `${pid}/${pinId}`;
    if (shotCache.has(key)) return { shot: shotCache.get(key) };
    const r = await fetch(`${SHOTS_URL}/shot/${pid}/${pinId}`, { headers: { Authorization: "Bearer " + (await token()) } });
    if (!r.ok) return { shot: null };
    const url = URL.createObjectURL(await r.blob());
    shotCache.set(key, url);
    return { shot: url };
  }
  function dropShot(pid, pinId) {
    const key = `${pid}/${pinId}`;
    const url = shotCache.get(key);
    if (url) { try { URL.revokeObjectURL(url); } catch {} shotCache.delete(key); }
  }
  // Leaving review mode: nothing can display these blobs any more.
  function releaseShots() {
    for (const url of shotCache.values()) { try { URL.revokeObjectURL(url); } catch {} }
    shotCache.clear();
  }
  async function deleteShot(pid, pinId) {
    dropShot(pid, pinId);
    try { await fetch(`${SHOTS_URL}/shot/${pid}/${pinId}`, { method: "DELETE", headers: { Authorization: "Bearer " + (await token()) } }); } catch {}
  }

  async function currentUser() {
    const s = await getSettings();
    if (!s.user || !s.user.id) throw new Error("unauthorized");
    return s.user;
  }

  async function api(path, opts = {}) {
    const method = (opts.method || "GET").toUpperCase();
    const body = opts.body ? JSON.parse(opts.body) : {};
    const [rawPath, query = ""] = path.split("?");
    const seg = rawPath.split("/").filter(Boolean);

    // POST /projects — create (popup, when the site has no project yet)
    if (seg[0] === "projects" && seg.length === 1 && method === "POST") {
      const u = await currentUser();
      const data = one(await rest(`/projects?select=${PROJECT_COLS}`, {
        method: "POST", prefer: "return=representation",
        // owner is left to the column default (auth.uid()), so a stale local
        // session id can't disagree with the token and trip projects_insert.
        body: { name: body.name, url: body.url || "", description: body.description || "", owner_email: u.email },
      }));
      return { project: mapProject(data) };
    }

    // GET /projects/find?url=…[&counts=1] — "does this site have a project?"
    // Runs on every page load, so it must stay one narrow query: filter on the
    // server (active projects whose url contains the host) and keep the exact
    // hostOf() comparison client-side. Counts cost extra round trips, so only
    // the popup — which actually displays them — asks for them.
    if (seg[0] === "projects" && seg[1] === "find") {
      const params = new URLSearchParams(query);
      const host = hostOf(params.get("url") || "");
      if (!host) return { project: null };
      // Match on the hostname only: a port would put a ':' in the pattern,
      // which PostgREST reads as a reserved character. hostOf() below is still
      // the authority, so the narrowing can safely be approximate.
      const needle = host.split(":")[0];
      const rows = await rest(
        `/projects?select=${PROJECT_COLS}&archived=is.false&url=ilike.${encodeURIComponent("*" + needle + "*")}`
      );
      const hit = (rows || []).find((p) => hostOf(p.url) === host);
      if (!hit) return { project: null };
      if (params.get("counts") !== "1") return { project: mapProject(hit) };
      const [total, resolved] = await Promise.all([
        restCount(`/pins?select=id&project_id=eq.${hit.id}`),
        restCount(`/pins?select=id&project_id=eq.${hit.id}&status=in.(resolved,done)`),
      ]);
      return { project: mapProject(hit), counts: { total, resolved, active: total - resolved } };
    }

    if (seg[0] === "projects" && seg[1]) {
      const pid = seg[1];

      // GET /projects/:id — project + every pin, opening review mode
      if (seg.length === 2 && method === "GET") {
        const proj = one(await rest(`/projects?select=${PROJECT_COLS}&id=eq.${pid}`));
        if (!proj) throw new Error("not_found");
        const pins = await rest(`/pins?select=*,comments(*)&project_id=eq.${pid}&order=created_at.asc&comments.order=created_at.asc`);
        return { project: mapProject(proj), pins: (pins || []).map(mapPin) };
      }

      if (seg[2] === "invites" && method === "POST") {
        // Route through the invite-user Edge Function (adds members + sends
        // Supabase's invite email to new addresses; in-app-notifies existing
        // users). Needs the service-role key, so it can't run in-page.
        const r = await fetch(`${SUPABASE_URL}/functions/v1/invite-user`, {
          method: "POST",
          headers: { apikey: SUPABASE_KEY, Authorization: "Bearer " + (await token()), "Content-Type": "application/json" },
          body: JSON.stringify({ projectId: pid, emails: body.emails || [] }),
        });
        const data = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(data.error || "invite_failed");
        const all = await rest(`/project_members?select=email&project_id=eq.${pid}`);
        return { members: (all || []).map((m) => m.email), added: data.added || [], emailed: data.emailed || [] };
      }

      if (seg[2] === "pins" && seg.length === 3 && method === "POST") {
        const u = await currentUser();
        const row = {
          project_id: pid, page_url: body.pageUrl || "", selector: body.selector || "",
          xr: body.xr || 0, yr: body.yr || 0, comment: body.comment || "",
          severity: body.severity || "neutral", status: body.status || "backlog", assignee: body.assignee || "",
          due: Number.isFinite(body.due) ? body.due : null, device: body.device || "desktop",
          viewport: body.viewport || "", has_shot: false, created_by: u.id, created_by_email: u.email,
        };
        const data = one(await rest("/pins?select=*,comments(*)&comments.order=created_at.asc", { method: "POST", prefer: "return=representation", body: row }));
        if (body.shot) {
          try { await uploadShot(pid, data.id, body.shot); await rest(`/pins?id=eq.${data.id}`, { method: "PATCH", prefer: "return=minimal", body: { has_shot: true } }); data.has_shot = true; }
          catch { /* pin saved without shot */ }
        }
        return { pin: mapPin(data) };
      }

      if (seg[2] === "pins" && seg[3]) {
        const hid = seg[3];
        if (seg[4] === "shot") return await getShot(pid, hid);

        if (seg[4] === "comments" && method === "POST") {
          const u = await currentUser();
          const name = u.name || (u.email || "").split("@")[0];
          const data = one(await rest("/comments?select=*", { method: "POST", prefer: "return=representation", body: { pin_id: hid, project_id: pid, author: u.id, author_email: u.email, author_name: name, text: body.text } }));
          return { comment: mapComment(data) };
        }
        if (method === "PATCH") {
          // Every caller updates its local copy first and drops this response,
          // so don't make the server serialise the pin and all its comments.
          const patch = {};
          for (const k of ["comment", "severity", "status", "assignee", "due"]) if (k in body) patch[k] = body[k];
          await rest(`/pins?id=eq.${hid}`, { method: "PATCH", prefer: "return=minimal", body: patch });
          return { ok: true };
        }
        if (method === "DELETE") {
          // The shot delete is fire-and-forget (it already swallows errors), so
          // run it alongside the row delete instead of ahead of it, and skip it
          // entirely for pins that never had a screenshot.
          const work = [rest(`/pins?id=eq.${hid}`, { method: "DELETE" })];
          if (body.hasShot !== false) work.push(deleteShot(pid, hid));
          else dropShot(pid, hid);
          await Promise.all(work);
          return { ok: true };
        }
      }
    }

    if (rawPath === "/auth/change-password" && method === "POST") {
      const r = await fetch(AUTH + "/user", { method: "PUT", headers: { apikey: SUPABASE_KEY, Authorization: "Bearer " + (await token()), "Content-Type": "application/json" }, body: JSON.stringify({ password: body.newPassword }) });
      if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.msg || "password_change_failed"); }
      return { ok: true };
    }

    // GET /notifications — the toolbar badge and the popup row both want counts,
    // never the rows, so ask Postgres to count and transfer nothing.
    if (seg[0] === "notifications" && method === "GET") {
      const [total, unread] = await Promise.all([
        restCount("/notifications?select=id"),
        restCount("/notifications?select=id&read=is.false"),
      ]);
      return { total, unread };
    }

    throw new Error("unrouted: " + method + " " + rawPath);
  }

  g.MarkoDB = { api, getSettings, setSettings, clearSession, isValid, releaseShots, isOwnSurface };
})();
