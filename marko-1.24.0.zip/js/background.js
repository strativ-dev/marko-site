"use strict";

importScripts("marko-db.js");

chrome.runtime.onInstalled.addListener((details) => {
  chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  chrome.action.setBadgeTextColor({ color: "#ffffff" });
  if (details.reason === "install") {
    chrome.storage.local.set({
      "marko:version": chrome.runtime.getManifest().version,
      "marko:settings": {},
    });
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome/welcome.html") });
  }
});

// ── mention badge ──
// Poll the backend for unread mentions and mirror the count on the toolbar
// icon. Alarms survive service-worker suspension; setInterval would not.
const BADGE_ALARM = "marko:mentions";
const BADGE_STAMP = "marko:badgeAt";
// Tab switches and window focus changes fire in bursts (hold ctrl-tab and you
// get one per tab), so event-driven refreshes coalesce into this window. The
// stamp lives in storage.session because the worker is torn down constantly
// and an in-memory variable would reset with it.
const BADGE_MIN_GAP_MS = 25_000;

async function refreshMentionBadge({ throttle = false } = {}) {
  try {
    if (throttle) {
      const store = chrome.storage.session || chrome.storage.local;
      const last = (await store.get(BADGE_STAMP))[BADGE_STAMP] || 0;
      if (Date.now() - last < BADGE_MIN_GAP_MS) return 0;
      await store.set({ [BADGE_STAMP]: Date.now() });
    }
    if (!MarkoDB.isValid(await MarkoDB.getSettings())) {
      await chrome.action.setBadgeText({ text: "" });
      return 0;
    }
    // Count-only query: the badge needs one integer, not 100 notification rows.
    const data = await MarkoDB.api("/notifications");
    const unread = Number(data.unread) || 0;
    await chrome.action.setBadgeText({ text: unread ? (unread > 9 ? "9+" : String(unread)) : "" });
    return unread;
  } catch {
    return 0;
  }
}

// A service worker can't hold a realtime websocket (it sleeps), so the badge
// is kept fresh by a short poll plus event-driven refreshes when the user
// switches tabs or refocuses the window — near-live without a socket.
//
// MV3 re-runs this whole file on every wake, so the alarm is only created when
// it is missing (re-creating it resets its schedule), the badge colour is set
// from the install/startup hooks instead of on every refresh, and there is no
// bare top-level refresh — the event that woke us runs its own.
chrome.alarms.get(BADGE_ALARM, (a) => {
  if (!a) chrome.alarms.create(BADGE_ALARM, { periodInMinutes: 1 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === BADGE_ALARM) refreshMentionBadge();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  chrome.action.setBadgeTextColor({ color: "#ffffff" });
  refreshMentionBadge();
});
chrome.tabs.onActivated.addListener(() => refreshMentionBadge({ throttle: true }));
if (chrome.windows?.onFocusChanged) {
  chrome.windows.onFocusChanged.addListener((id) => {
    if (id !== chrome.windows.WINDOW_ID_NONE) refreshMentionBadge({ throttle: true });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;

  (async () => {
    try {
      switch (msg.type) {
        case "MARKO_CAPTURE_VISIBLE": {
          const windowId = sender.tab?.windowId;
          const dataUrl = await chrome.tabs.captureVisibleTab(windowId, {
            format: "png",
          });
          sendResponse({ ok: true, dataUrl });
          break;
        }
        case "MARKO_RESIZE_WINDOW": {
          // Resize the browser window so the page viewport approximates the
          // requested device size (add chrome for toolbar and frame).
          const win = await chrome.windows.get(sender.tab.windowId);
          const chromeW = Math.max(0, win.width - (sender.tab.width || win.width));
          const w = Math.max(320, Math.round(msg.width)) + chromeW;
          const h = Math.max(400, Math.round(msg.height)) + 90;
          await chrome.windows.update(sender.tab.windowId, {
            state: "normal",
            width: w,
            height: h,
          });
          sendResponse({ ok: true });
          break;
        }
        default:
          sendResponse({ ok: false, error: "unknown_type" });
      }
    } catch (err) {
      sendResponse({ ok: false, error: String(err?.message || err) });
    }
  })();

  return true; // async response
});

chrome.action.onClicked.addListener(() => {
  // popup handles UI — this fires only if popup fails
});
