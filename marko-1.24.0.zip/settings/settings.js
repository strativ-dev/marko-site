"use strict";

const SETTINGS_KEY = "marko:settings";

const $ = (s) => document.querySelector(s);

async function load() {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  $("#default-tool").value = settings.defaultTool || "pin";
  $("#default-severity").value = settings.defaultSeverity || "neutral";
  $("#team-members").value = (settings.teamMembers || []).join("\n");
  $("#custom-guidelines").value = (settings.customGuidelines || []).join("\n");
  renderAccount(settings);
  await refreshStats();
}

function renderAccount(settings) {
  const u = settings.user || {};
  $("#account-email").textContent = u.email || "—";
  const exp = settings.sbExp || 0;
  $("#account-exp").textContent = exp
    ? new Date(exp).toLocaleString()
    : "no active session";
  $("#display-name").value = u.name || "";
}

async function saveAccount() {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  const name = $("#display-name").value.trim();
  settings.user = {
    ...(settings.user || {}),
    name: name || (settings.user?.email || "").split("@")[0] || "",
  };
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  flash("#account-save-status");
}

async function changePassword() {
  const status = $("#cp-status");
  const newPw = $("#cp-new").value;
  if (newPw.length < 8) {
    status.textContent = "New password must be 8+ characters.";
    status.className = "status err";
    return;
  }
  if (!MarkoDB.isValid(await MarkoDB.getSettings())) {
    status.textContent = "Sign in from the popup first.";
    status.className = "status err";
    return;
  }
  status.textContent = "Updating…";
  status.className = "status";
  try {
    await MarkoDB.api("/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ newPassword: newPw }),
    });
    status.textContent = "Password updated.";
    status.className = "status ok";
    $("#cp-old").value = "";
    $("#cp-new").value = "";
  } catch (e) {
    status.textContent = "Failed: " + (e.message || e);
    status.className = "status err";
  }
}

// Two-step confirm in place of a blocking browser confirm(): first click arms
// the button (label changes), a second click within 3s runs the action.
function armConfirm(btn, confirmLabel, onConfirm) {
  const orig = btn.textContent;
  let armed = false, t = null;
  btn.addEventListener("click", async () => {
    if (!armed) {
      armed = true; btn.textContent = confirmLabel; btn.classList.add("danger");
      t = setTimeout(() => { armed = false; btn.textContent = orig; btn.classList.remove("danger"); }, 3000);
      return;
    }
    clearTimeout(t); armed = false; btn.textContent = orig; btn.classList.remove("danger");
    await onConfirm();
  });
}

async function signOut() {
  await MarkoDB.clearSession();
  renderAccount(await MarkoDB.getSettings());
}

function parseLines(v) {
  return v
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean)
    .filter((s, i, a) => a.indexOf(s) === i)
    .slice(0, 50);
}

async function saveTeam() {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  settings.teamMembers = parseLines($("#team-members").value);
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  flash("#team-status");
}

async function saveGuidelines() {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  settings.customGuidelines = parseLines($("#custom-guidelines").value);
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  flash("#guidelines-status");
}

function flash(sel) {
  const el = $(sel);
  el.textContent = "Saved";
  el.className = "status ok";
  setTimeout(() => { el.textContent = ""; }, 1500);
}

async function saveDefaults() {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  settings.defaultTool = $("#default-tool").value;
  settings.defaultSeverity = $("#default-severity").value;
  settings.defaultsExplicit = true;
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  const el = $("#defaults-status");
  el.textContent = "Saved";
  el.className = "status ok";
  setTimeout(() => { el.textContent = ""; }, 1500);
}

function showStatus(text, cls) {
  const el = $("#status");
  el.textContent = text;
  el.className = "status" + (cls ? " " + cls : "");
}

async function refreshStats() {
  const all = await chrome.storage.local.get(null);
  let reports = 0, projects = 0, drafts = 0, bytes = 0;
  for (const [k, v] of Object.entries(all)) {
    if (k.startsWith("marko:report:")) reports++;
    else if (k.startsWith("marko:project:")) projects++;
    else if (k.startsWith("marko:page:")) drafts++;
    bytes += JSON.stringify(v).length;
  }
  $("#stat-reports").textContent = reports;
  $("#stat-projects").textContent = projects;
  $("#stat-drafts").textContent = drafts;
  $("#stat-bytes").textContent = fmtBytes(bytes);
}

function fmtBytes(n) {
  if (n < 1024) return n + " B";
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
  return (n / (1024 * 1024)).toFixed(2) + " MB";
}

$("#save-defaults").addEventListener("click", saveDefaults);
$("#save-team").addEventListener("click", saveTeam);
$("#save-guidelines").addEventListener("click", saveGuidelines);
$("#save-account").addEventListener("click", saveAccount);
$("#change-password").addEventListener("click", changePassword);
armConfirm($("#signout"), "Confirm sign out", signOut);
$("#clear-recents").addEventListener("click", async () => {
  const res = await chrome.storage.local.get(SETTINGS_KEY);
  const settings = res[SETTINGS_KEY] || {};
  settings.recentColors = [];
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  showStatus("Recent colors cleared.", "ok");
});
armConfirm($("#wipe"), "Confirm wipe — deletes everything", async () => {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith("marko:"));
  await chrome.storage.local.remove(keys);
  await load();
  showStatus("Wiped.", "ok");
});

load();
