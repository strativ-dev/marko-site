"use strict";

const SEV_LABELS = {
  neutral: "Neutral",
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

const GUIDELINE_LABELS = {
  visibility: "Visibility of system status",
  match: "Match between system and real world",
  control: "User control and freedom",
  consistency: "Consistency and standards",
  "error-prevention": "Error prevention",
  recognition: "Recognition rather than recall",
  flexibility: "Flexibility and efficiency of use",
  minimalist: "Aesthetic and minimalist design",
  "error-recovery": "Help users recover from errors",
  help: "Help and documentation",
  custom: "Custom / other",
};

function esc(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[c]));
}

function fmtDate(ts) {
  if (!ts) return "—";
  return new Date(ts).toLocaleString();
}

function renderMentionText(root, text) {
  root.textContent = "";
  const parts = String(text || "").split(/(@[\w.\-]+)/g);
  parts.forEach((part) => {
    if (/^@[\w.\-]+$/.test(part)) {
      const span = document.createElement("span");
      span.className = "mention";
      span.textContent = part;
      root.appendChild(span);
    } else if (part) {
      root.appendChild(document.createTextNode(part));
    }
  });
}

function pinsOf(r) {
  return (r.shapes || []).filter((s) => s.type === "pin");
}

async function load() {
  const container = document.getElementById("content");
  // The fragment carries the whole base64 report, so parse it once and reuse
  // it for the deep-link lookup below.
  const fragParams = new URLSearchParams(location.hash.replace(/^#/, ""));
  try {
    let report = null;
    // Priority: inline data (from standalone HTML) → URL fragment → error
    if (window.__MARKO_INLINE_DATA__) {
      report = window.__MARKO_INLINE_DATA__;
    } else {
      const data = fragParams.get("data");
      if (!data) {
        renderError(container, "No report data provided.", "Add `#data=<base64>` to the URL, or open a standalone HTML export.");
        return;
      }
      if (!window.__MARKO_SHARE__) {
        renderError(container, "Share module missing.", "");
        return;
      }
      report = await window.__MARKO_SHARE__.decodeReport(data);
    }
    if (!report || typeof report !== "object") {
      renderError(container, "Bad report payload.", "");
      return;
    }
    if (report.marko === "project-export" && Array.isArray(report.reports)) {
      renderProject(container, report);
      document.title =
        ((report.project && report.project.name) || "Project") + " — Marko";
      return;
    }
    renderReport(container, report);
    document.title =
      (report.title || "Report") + " — Marko";

    // Deep link: #data=...&pin=N or ?pin=N → scroll + flash that pin card
    const pinN =
      fragParams.get("pin") ||
      new URLSearchParams(location.search).get("pin");
    if (pinN) {
      const card = document.getElementById("pin-" + pinN);
      if (card) {
        setTimeout(() => {
          card.scrollIntoView({ behavior: "smooth", block: "center" });
          card.classList.add("flash");
          setTimeout(() => card.classList.remove("flash"), 2400);
        }, 150);
      }
    }
  } catch (err) {
    renderError(container, "Could not read report.", String(err.message || err));
  }
}

function renderError(root, title, detail) {
  root.innerHTML = `<div class="error"><h2>${esc(title)}</h2><p>${esc(detail)}</p></div>`;
}

function renderProject(root, payload) {
  const p = payload.project || {};
  const reports = payload.reports.filter(Boolean);
  root.innerHTML = "";

  const times = reports
    .flatMap((r) => [r.createdAt, r.updatedAt])
    .filter(Boolean);
  const from = times.length ? new Date(Math.min(...times)) : null;
  const to = times.length ? new Date(Math.max(...times)) : null;

  const head = document.createElement("div");
  head.className = "rpt-head";
  head.innerHTML = `
    <h1>${esc(p.name || "Project")}</h1>
    ${p.siteRoot ? `<a class="url" href="${esc(p.siteRoot)}" target="_blank" rel="noopener">${esc(p.siteRoot)}</a>` : ""}
    ${p.description ? `<p>${esc(p.description)}</p>` : ""}
    <div class="meta-pills">
      <span class="pill">${reports.length} report${reports.length === 1 ? "" : "s"}</span>
      ${from ? `<span class="pill">From ${from.toLocaleDateString()}</span>` : ""}
      ${to ? `<span class="pill">To ${to.toLocaleDateString()}</span>` : ""}
    </div>
    <div class="meta-pills sev-legend">
      ${Object.entries(SEV_LABELS).map(([id, label]) =>
        `<span class="pill severity sev-${id}">${label}</span>`).join("")}
    </div>
  `;
  root.appendChild(head);

  reports
    .sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0))
    .forEach((r) => {
      const section = document.createElement("div");
      section.className = "project-report";
      renderReport(section, r, { noFooter: true });
      root.appendChild(section);
    });

  const foot = document.createElement("footer");
  foot.className = "footer";
  foot.innerHTML = `Rendered by <a href="https://github.com/strativ-dev/marko-ux-tool" target="_blank" rel="noopener">Marko</a> — free bug-report &amp; UX-check extension`;
  root.appendChild(foot);
}

function renderReport(root, r, opts = {}) {
  const sev = r.severity || "neutral";
  const pins = pinsOf(r);
  const meta = r.meta || {};

  root.innerHTML = "";

  // Head
  const head = document.createElement("div");
  head.className = "rpt-head";
  head.innerHTML = `
    <h1>${esc(r.title || r.note || "(untitled)")}</h1>
    ${r.url ? `<a class="url" href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.url)}</a>` : ""}
    <div class="meta-pills">
      <span class="pill severity sev-${sev}">${SEV_LABELS[sev] || sev}</span>
      ${r.active ? `<span class="pill">Active</span>` : `<span class="pill resolved">Resolved</span>`}
      <span class="pill">Created ${fmtDate(r.createdAt)}</span>
      ${meta.os ? `<span class="pill">${esc(meta.os)}</span>` : ""}
      ${meta.browser ? `<span class="pill">${esc(meta.browser)}</span>` : ""}
      ${meta.viewport ? `<span class="pill">${meta.viewport.w}×${meta.viewport.h} px</span>` : ""}
      ${pins.length ? `<span class="pill">${pins.length} pins</span>` : ""}
    </div>
  `;
  root.appendChild(head);

  // Body: screenshot + description column
  const body = document.createElement("div");
  body.className = "rpt-body";

  const shot = document.createElement("div");
  shot.className = "screenshot-wrap";
  if (r.screenshot) {
    const img = document.createElement("img");
    img.src = r.screenshot;
    shot.appendChild(img);
  } else {
    shot.classList.add("empty");
    shot.textContent = "No screenshot";
  }
  body.appendChild(shot);

  const desc = document.createElement("div");
  desc.className = "desc";

  desc.appendChild(sectionHTML("Note", r.note));
  desc.appendChild(sectionHTML("Suggestion", r.suggestion));
  body.appendChild(desc);

  root.appendChild(body);

  // Pins
  if (pins.length) {
    const heading = document.createElement("h2");
    heading.textContent = "Pins";
    heading.style.marginTop = "32px";
    heading.style.fontSize = "16px";
    root.appendChild(heading);

    const list = document.createElement("div");
    list.className = "pins";
    pins.forEach((p) => list.appendChild(pinCard(p)));
    root.appendChild(list);
  }

  if (!opts.noFooter) {
    const foot = document.createElement("footer");
    foot.className = "footer";
    foot.innerHTML = `Rendered by <a href="https://github.com/strativ-dev/marko-ux-tool" target="_blank" rel="noopener">Marko</a> — free bug-report &amp; UX-check extension`;
    root.appendChild(foot);
  }
}

function sectionHTML(title, text) {
  const s = document.createElement("div");
  s.className = "section";
  s.innerHTML = `<h3>${esc(title)}</h3>`;
  const t = document.createElement("div");
  t.className = "txt" + ((text || "").trim() ? "" : " empty");
  t.textContent = (text || "").trim() || "—";
  s.appendChild(t);
  return s;
}

function pinCard(p) {
  const card = document.createElement("div");
  card.className = "pin-card";
  card.id = "pin-" + p.n;

  const num = document.createElement("div");
  num.className = "pin-num";
  num.style.background = p.color || "#ff3355";
  num.textContent = p.n;
  card.appendChild(num);

  const body = document.createElement("div");
  body.className = "pin-body";

  const title = document.createElement("h4");
  title.textContent = p.note ? p.note.split("\n")[0].slice(0, 100) : `Pin #${p.n}`;
  body.appendChild(title);

  const sub = document.createElement("div");
  sub.className = "subline";
  const sev = p.severity || "neutral";
  const guidelineLabel = p.guideline
    ? (GUIDELINE_LABELS[p.guideline] ||
       (p.guideline.startsWith("custom:") ? p.guideline.slice(7) : ""))
    : "";
  sub.innerHTML = `
    <span class="pill severity sev-${sev}">${SEV_LABELS[sev]}</span>
    ${p.resolved ? `<span class="pill resolved">Resolved</span>` : ""}
    ${p.author ? `<span class="pill">by ${esc(p.author)}</span>` : ""}
    ${p.assignee ? `<span class="pill">@${esc(p.assignee)}</span>` : ""}
    ${p.dueDate ? `<span class="pill">Due ${esc(p.dueDate)}</span>` : ""}
    ${guidelineLabel ? `<span class="pill">${esc(guidelineLabel)}</span>` : ""}
  `;
  body.appendChild(sub);

  if (p.anchor?.selector) {
    const a = document.createElement("div");
    a.className = "anchor";
    a.textContent = p.anchor.selector;
    body.appendChild(a);
  }

  if (p.note && p.note.trim() && p.note.split("\n").length > 1) {
    body.appendChild(labeled("Note", p.note));
  }
  if (p.suggestion && p.suggestion.trim()) {
    body.appendChild(labeled("Suggestion", p.suggestion));
  }
  if ((p.comments || []).length) {
    body.appendChild(commentsBlock(p.comments));
  }

  card.appendChild(body);
  return card;
}

function labeled(label, text) {
  const wrap = document.createElement("div");
  const l = document.createElement("div");
  l.className = "label";
  l.textContent = label;
  const t = document.createElement("div");
  t.className = "note";
  t.textContent = text;
  wrap.appendChild(l);
  wrap.appendChild(t);
  return wrap;
}

function commentsBlock(comments) {
  const wrap = document.createElement("div");
  const l = document.createElement("div");
  l.className = "label";
  l.textContent = `Comments (${comments.length})`;
  wrap.appendChild(l);
  const list = document.createElement("div");
  list.className = "comments";
  comments.forEach((c) => {
    const item = document.createElement("div");
    item.className = "comment";
    const time = document.createElement("span");
    time.className = "time";
    time.textContent =
      (c.author ? c.author + " · " : "") + fmtDate(c.createdAt);
    const body = document.createElement("div");
    renderMentionText(body, c.text);
    item.appendChild(time);
    item.appendChild(body);
    if (c.attachment) {
      const att = document.createElement("img");
      att.className = "c-attach";
      att.src = c.attachment;
      att.addEventListener("click", () => att.classList.toggle("expanded"));
      item.appendChild(att);
    }
    list.appendChild(item);
  });
  wrap.appendChild(list);
  return wrap;
}

load().then(() => {
  const params = new URLSearchParams(location.search);
  if (params.get("print") === "1") {
    // Wait for images to load, then trigger print dialog
    const imgs = Array.from(document.images);
    const done = (imgs.length
      ? Promise.all(
          imgs.map((img) =>
            img.complete
              ? Promise.resolve()
              : new Promise((r) => {
                  img.addEventListener("load", r, { once: true });
                  img.addEventListener("error", r, { once: true });
                })
          )
        )
      : Promise.resolve());
    done.then(() => setTimeout(() => window.print(), 200));
  }
});
